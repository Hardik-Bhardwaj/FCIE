import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { pilotRequestsTable, insertPilotRequestSchema } from "@workspace/db";

const router: IRouter = Router();

router.post("/pilot", async (req, res) => {
  const parsed = insertPilotRequestSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request", details: parsed.error.issues });
    return;
  }

  try {
    const [row] = await db
      .insert(pilotRequestsTable)
      .values(parsed.data)
      .returning({ id: pilotRequestsTable.id });

    req.log.info({ id: row?.id }, "Pilot request submitted");
    res.status(201).json({ success: true, id: row?.id });
  } catch (err) {
    req.log.error({ err }, "Failed to insert pilot request");
    res.status(500).json({ error: "Failed to save request" });
  }
});

export default router;
