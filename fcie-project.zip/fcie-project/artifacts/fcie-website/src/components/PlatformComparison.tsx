import { motion } from "framer-motion";
import { Check, X, Minus } from "lucide-react";

const ease = [0.16, 1, 0.3, 1] as const;

type CellValue = "yes" | "no" | "partial" | string;

interface Row {
  label: string;
  sub?: string;
  fcie: CellValue;
  inhouse: CellValue;
  nothing: CellValue;
}

const ROWS: Row[] = [
  { label: "Time to value", fcie: "6 weeks", inhouse: "12–18 months", nothing: "Never" },
  { label: "Upfront cost", fcie: "Revenue-share", inhouse: "₹2–8Cr build cost", nothing: "₹0" },
  { label: "Conversion lift", sub: "vs current baseline", fcie: "+3–5%", inhouse: "Unknown", nothing: "0%" },
  { label: "Real-time inactivity signals", fcie: "yes", inhouse: "partial", nothing: "no" },
  { label: "Risk scoring per student", fcie: "yes", inhouse: "partial", nothing: "no" },
  { label: "Lender-fit routing", fcie: "yes", inhouse: "no", nothing: "no" },
  { label: "Document intelligence", fcie: "yes", inhouse: "partial", nothing: "no" },
  { label: "Counselor intervention queue", fcie: "yes", inhouse: "no", nothing: "no" },
  { label: "Auto WhatsApp / Email nudges", fcie: "yes", inhouse: "partial", nothing: "no" },
  { label: "Model retraining on your data", fcie: "yes", inhouse: "yes", nothing: "no" },
  { label: "Maintenance burden on your team", fcie: "Zero", inhouse: "High", nothing: "Zero" },
  { label: "Expected revenue impact / year", sub: "3,000 students/month platform", fcie: "+₹25Cr", inhouse: "+₹10–18Cr (if built)", nothing: "₹0" },
];

function Cell({ value }: { value: CellValue }) {
  if (value === "yes") {
    return (
      <div className="flex items-center justify-center">
        <Check className="w-4 h-4 text-emerald-600" strokeWidth={2.5} />
      </div>
    );
  }
  if (value === "no") {
    return (
      <div className="flex items-center justify-center">
        <X className="w-4 h-4 text-red-400" strokeWidth={2.5} />
      </div>
    );
  }
  if (value === "partial") {
    return (
      <div className="flex items-center justify-center">
        <Minus className="w-4 h-4 text-amber-500" strokeWidth={2.5} />
      </div>
    );
  }
  return (
    <div className="flex items-center justify-center">
      <span className="text-sm font-mono font-semibold text-black">{value}</span>
    </div>
  );
}

export default function PlatformComparison() {
  return (
    <section className="py-32 md:py-48 px-6 bg-[#F5F5F7]">
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, ease }}
          className="mb-14"
        >
          <p className="text-sm font-mono text-[#6E6E73] uppercase tracking-widest mb-4">
            Build vs Buy vs Do Nothing
          </p>
          <h2 className="text-4xl md:text-5xl font-black tracking-tight text-black mb-4">
            Three paths.
            <br />
            <span className="text-[#6E6E73] font-light">One obvious answer.</span>
          </h2>
          <p className="text-lg text-[#6E6E73] font-light max-w-xl">
            Every founder considers building in-house. Here's what that actually means in time, cost, and outcomes — compared to deploying FCIE in six weeks.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, ease, delay: 0.1 }}
          className="overflow-x-auto"
        >
          <table className="w-full border-collapse min-w-[600px]">
            {/* Header */}
            <thead>
              <tr>
                <th className="text-left py-4 px-5 w-[45%] bg-white border border-black/8 text-xs font-mono text-[#6E6E73] uppercase tracking-widest font-normal">
                  Capability
                </th>
                <th className="py-4 px-4 w-[18%] bg-black text-white border border-black text-xs font-mono uppercase tracking-widest font-bold text-center">
                  FCIE
                </th>
                <th className="py-4 px-4 w-[18%] bg-white border border-black/8 text-xs font-mono text-[#6E6E73] uppercase tracking-widest font-normal text-center">
                  Build In-House
                </th>
                <th className="py-4 px-4 w-[19%] bg-white border border-black/8 text-xs font-mono text-[#6E6E73] uppercase tracking-widest font-normal text-center">
                  Do Nothing
                </th>
              </tr>
            </thead>
            <tbody>
              {ROWS.map((row, i) => (
                <motion.tr
                  key={i}
                  initial={{ opacity: 0, x: -8 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, ease, delay: i * 0.04 }}
                  className={`${i % 2 === 0 ? "bg-white" : "bg-[#FAFAFA]"}`}
                >
                  <td className="py-3.5 px-5 border border-black/8">
                    <span className="text-sm font-medium text-black">{row.label}</span>
                    {row.sub && (
                      <span className="block text-[11px] text-[#6E6E73] mt-0.5">{row.sub}</span>
                    )}
                  </td>
                  <td className="py-3.5 px-4 border border-black/8 bg-black/[0.02]">
                    <Cell value={row.fcie} />
                  </td>
                  <td className="py-3.5 px-4 border border-black/8">
                    <Cell value={row.inhouse} />
                  </td>
                  <td className="py-3.5 px-4 border border-black/8">
                    <Cell value={row.nothing} />
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </motion.div>

        {/* Footnote */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.5 }}
          className="mt-6 flex flex-wrap gap-6 text-xs font-mono text-[#6E6E73]"
        >
          <span className="flex items-center gap-1.5"><Check className="w-3 h-3 text-emerald-600" /> Fully available</span>
          <span className="flex items-center gap-1.5"><Minus className="w-3 h-3 text-amber-500" /> Partial / requires custom work</span>
          <span className="flex items-center gap-1.5"><X className="w-3 h-3 text-red-400" /> Not available</span>
          <span className="ml-auto">Revenue impact based on 3,000 students/month platform. Conservative 50% of benchmark uplift applied.</span>
        </motion.div>
      </div>
    </section>
  );
}
