import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

const ease = [0.16, 1, 0.3, 1] as const;

interface FunnelStage {
  stage: string;
  current: number;
  fcie: number;
  dropCount: number;
  recoverable: number;
  rootCauses: string[];
  fcieActions: string[];
}

const FUNNEL: FunnelStage[] = [
  {
    stage: "Inquiry",
    current: 100,
    fcie: 100,
    dropCount: 0,
    recoverable: 0,
    rootCauses: ["Baseline — all students start here"],
    fcieActions: ["Journey Event Layer begins tracking from first touch"],
  },
  {
    stage: "Profile Complete",
    current: 59.6,
    fcie: 64,
    dropCount: 404,
    recoverable: 44,
    rootCauses: [
      "40% of students abandon before completing their academic profile",
      "High friction in GRE / GPA entry flow",
      "No re-engagement nudge within 48 hours of signup",
    ],
    fcieActions: [
      "Automated WhatsApp completion prompt at 24h inactivity",
      "Counselor callback triggered at 48h stall",
      "Personalized incomplete-profile nudge",
    ],
  },
  {
    stage: "Shortlisted",
    current: 44.4,
    fcie: 50,
    dropCount: 152,
    recoverable: 56,
    rootCauses: [
      "Students overwhelmed by university-lender combination choices",
      "No guidance on which programs fit their financial profile",
      "Counselor response latency averaging 9 days",
    ],
    fcieActions: [
      "Lender-fit scoring surfaces best match instantly",
      "Counselor queue prioritises stalled shortlisters",
      "Auto-generated shortlist recommendation based on profile",
    ],
  },
  {
    stage: "Loan Started",
    current: 29.2,
    fcie: 34,
    dropCount: 152,
    recoverable: 48,
    rootCauses: [
      "Income-to-loan ratio mismatch not caught early",
      "Collateral confusion for first-time applicants",
      "Lender requirement gaps discovered late",
    ],
    fcieActions: [
      "Financial stress flag triggers counseling session",
      "Lender compatibility check runs at loan start",
      "Alternative lender suggestion if mismatch detected",
    ],
  },
  {
    stage: "Docs Submitted",
    current: 18.4,
    fcie: 23,
    dropCount: 108,
    recoverable: 46,
    rootCauses: [
      "38% of applications have at least one missing document",
      "Income mismatch between profile and submitted docs",
      "IELTS/TOEFL not uploaded for US loans",
    ],
    fcieActions: [
      "Document Intelligence scans every upload on arrival",
      "Income mismatch flag raised before lender review",
      "Automated IELTS checklist for eligible profiles",
    ],
  },
  {
    stage: "Funded",
    current: 6.2,
    fcie: 9.2,
    dropCount: 295,
    recoverable: 55,
    rootCauses: [
      "Lender rejection due to incomplete documentation",
      "Co-applicant income below lender minimum",
      "Application momentum lost during lender processing wait",
    ],
    fcieActions: [
      "Full document validation before lender submission",
      "Lender rerouting if rejection risk is high",
      "Counselor follow-up scheduled during lender wait period",
    ],
  },
];

export default function InteractiveFunnel() {
  const [hovered, setHovered] = useState<number | null>(null);

  return (
    <section className="py-32 md:py-48 px-6 bg-[#F5F5F7]">
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, ease }}
          className="mb-16"
        >
          <p className="text-sm font-mono text-[#6E6E73] uppercase tracking-widest mb-4">
            Interactive Funnel — Hover each stage
          </p>
          <h2 className="text-4xl md:text-5xl font-black tracking-tight text-black mb-4">
            Every dropout has a cause.
            <br />
            <span className="text-[#6E6E73] font-light">Every cause has a fix.</span>
          </h2>
          <p className="text-lg text-[#6E6E73] font-light max-w-xl">
            Hover any funnel stage to see the root causes of dropout at that point and the exact FCIE intervention that recovers it.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-[1fr_360px] gap-8 items-start">
          {/* Funnel bars */}
          <div className="space-y-3">
            {FUNNEL.map((row, i) => {
              const isHovered = hovered === i;
              const gap = row.fcie - row.current;
              return (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -16 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, ease, delay: i * 0.07 }}
                  className="cursor-pointer group"
                  onMouseEnter={() => setHovered(i)}
                  onMouseLeave={() => setHovered(null)}
                  onTouchStart={() => setHovered(i === hovered ? null : i)}
                >
                  <div className="flex items-center gap-3 mb-1.5">
                    <span className="w-32 text-xs font-mono text-[#6E6E73] text-right shrink-0 uppercase tracking-wide">
                      {row.stage}
                    </span>
                    <div className="flex-1 flex flex-col gap-1">
                      {/* Current */}
                      <div className="flex items-center gap-2">
                        <div
                          className="h-6 bg-black/10 rounded-sm transition-all duration-300"
                          style={{ width: `${row.current}%` }}
                        />
                        <span className="text-xs font-mono text-[#6E6E73] shrink-0">{row.current}%</span>
                      </div>
                      {/* FCIE */}
                      <div className="flex items-center gap-2">
                        <motion.div
                          initial={{ width: 0 }}
                          whileInView={{ width: `${row.current}%` }}
                          viewport={{ once: true }}
                          transition={{ duration: 1.0, ease, delay: i * 0.1 }}
                          className="h-6 bg-black rounded-sm relative overflow-hidden"
                        >
                          {/* FCIE uplift */}
                          <motion.div
                            initial={{ width: 0 }}
                            whileInView={{ width: `${gap > 0 ? (gap / row.fcie) * 100 : 0}%` }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.8, ease, delay: i * 0.1 + 0.6 }}
                            className="absolute right-0 top-0 bottom-0 bg-blue-500/80"
                          />
                        </motion.div>
                        {gap > 0 && (
                          <span className="text-xs font-mono text-black font-bold shrink-0">
                            {row.fcie}% <span className="text-blue-600">(+{gap.toFixed(1)})</span>
                          </span>
                        )}
                        {gap === 0 && (
                          <span className="text-xs font-mono text-black font-bold shrink-0">{row.fcie}%</span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Inline hint */}
                  {row.dropCount > 0 && (
                    <div className="ml-[8.5rem] flex items-center gap-2">
                      <span className={`text-[10px] font-mono transition-colors ${isHovered ? "text-black" : "text-[#6E6E73]"}`}>
                        {row.dropCount} students drop here /month
                      </span>
                      {row.recoverable > 0 && (
                        <span className="text-[10px] font-mono text-blue-600">
                          · {row.recoverable} recoverable with FCIE
                        </span>
                      )}
                    </div>
                  )}
                </motion.div>
              );
            })}

            {/* Legend */}
            <div className="ml-[8.5rem] flex items-center gap-5 mt-6 text-xs font-mono text-[#6E6E73]">
              <span className="flex items-center gap-1.5"><span className="w-4 h-2.5 bg-black/10 rounded-sm inline-block" /> Current</span>
              <span className="flex items-center gap-1.5"><span className="w-4 h-2.5 bg-black rounded-sm inline-block" /> With FCIE</span>
              <span className="flex items-center gap-1.5"><span className="w-4 h-2.5 bg-blue-500/80 rounded-sm inline-block" /> FCIE uplift</span>
            </div>
          </div>

          {/* Detail panel */}
          <div className="lg:sticky lg:top-24">
            <AnimatePresence mode="wait">
              {hovered !== null ? (
                <motion.div
                  key={hovered}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.3, ease }}
                  className="bg-black text-white p-7"
                >
                  <div className="flex items-start justify-between mb-6">
                    <div>
                      <p className="text-xs font-mono text-white/30 uppercase tracking-widest mb-1">
                        Stage {hovered + 1} of {FUNNEL.length}
                      </p>
                      <h3 className="text-xl font-black">{FUNNEL[hovered].stage}</h3>
                    </div>
                    {FUNNEL[hovered].dropCount > 0 && (
                      <div className="text-right">
                        <div className="text-2xl font-black font-mono text-red-400">{FUNNEL[hovered].dropCount}</div>
                        <div className="text-[10px] font-mono text-white/30">drop / month</div>
                      </div>
                    )}
                  </div>

                  {FUNNEL[hovered].dropCount > 0 && (
                    <>
                      <div className="mb-5">
                        <p className="text-[10px] font-mono text-white/30 uppercase tracking-widest mb-3">Root Causes</p>
                        <ul className="space-y-2">
                          {FUNNEL[hovered].rootCauses.map((c, i) => (
                            <li key={i} className="flex items-start gap-2 text-xs text-white/60">
                              <span className="text-red-400 shrink-0 mt-0.5">—</span>
                              {c}
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="border-t border-white/10 pt-5">
                        <p className="text-[10px] font-mono text-white/30 uppercase tracking-widest mb-3">
                          FCIE Intervention
                        </p>
                        <ul className="space-y-2">
                          {FUNNEL[hovered].fcieActions.map((a, i) => (
                            <li key={i} className="flex items-start gap-2 text-xs text-white/70">
                              <span className="text-blue-400 shrink-0 mt-0.5">+</span>
                              {a}
                            </li>
                          ))}
                        </ul>
                        <div className="mt-5 pt-4 border-t border-white/10 flex items-center justify-between">
                          <span className="text-[10px] font-mono text-white/30">Recoverable / month</span>
                          <span className="text-lg font-black font-mono text-blue-400">
                            +{FUNNEL[hovered].recoverable}
                          </span>
                        </div>
                      </div>
                    </>
                  )}

                  {FUNNEL[hovered].dropCount === 0 && (
                    <p className="text-sm text-white/40 font-light">{FUNNEL[hovered].rootCauses[0]}</p>
                  )}
                </motion.div>
              ) : (
                <motion.div
                  key="empty"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="bg-[#E8E8ED] p-7 flex flex-col items-center justify-center text-center min-h-[200px]"
                >
                  <p className="text-sm text-[#6E6E73] font-light">
                    Hover any funnel stage to see dropout root causes and FCIE interventions.
                  </p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
}
