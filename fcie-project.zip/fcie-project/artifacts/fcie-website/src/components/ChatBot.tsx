import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MessageCircle, X, Send, ArrowRight } from "lucide-react";

const ease = [0.16, 1, 0.3, 1] as const;

interface Message {
  id: string;
  role: "bot" | "user";
  text: string;
  suggestions?: string[];
}

interface BotResponse {
  text: string;
  suggestions?: string[];
}

// ── Knowledge base ──────────────────────────────────────────────
const KB: { patterns: RegExp[]; response: BotResponse }[] = [
  {
    patterns: [/what is fcie/i, /what does fcie do/i, /explain fcie/i, /tell me about/i, /what are you/i],
    response: {
      text: "FCIE — Fundability & Conversion Intelligence Engine — is an AI operating layer built specifically for student financing platforms.\n\nIt watches every student journey in real time, scores each applicant's dropout risk, and tells your counselors exactly who to contact, what to say, and which action has the highest probability of saving that journey.\n\nThe prototype was trained on 3,000 real student records and achieves AUC 0.80–0.87 on predicting funding outcomes.",
      suggestions: ["What's the ROI?", "How does it work technically?", "How fast can we deploy?"],
    },
  },
  {
    patterns: [/how does it work/i, /technical/i, /how is it built/i, /architecture/i, /model/i, /xgboost/i, /ml/i, /machine learning/i],
    response: {
      text: "FCIE runs on three layers:\n\n1. Journey Event Layer — captures every click, upload, counselor interaction, and inactivity window in real time.\n\n2. Risk Scoring Engine — an XGBoost model trained on 35 features (GRE, income, document completeness, lender fit, funnel stage, RFM signals). Scores every student continuously.\n\n3. Intervention Orchestrator — selects the right action from a ranked library: WhatsApp nudge, counselor callback, lender reroute, or escalation. Delivered at the right moment.",
      suggestions: ["What's the conversion lift?", "Which lenders does it integrate?", "How long to set up?"],
    },
  },
  {
    patterns: [/roi/i, /revenue/i, /₹|crore|cr\b/i, /money/i, /return/i, /profit/i, /impact/i],
    response: {
      text: "For a platform processing 3,000 students/month:\n\n• Conversion: 6.2% → 9.2% funded (conservative model)\n• +55 additional funded students/month\n• +₹2.1Cr/month in disbursement fees\n• +₹25Cr/year at full deployment\n\nThese numbers are based on GradRight public data (BusinessToday, Jan 2024) with a 50% conservative discount applied to industry benchmarks.\n\nSmaller platforms scale proportionally.",
      suggestions: ["How is pricing structured?", "When do we see results?", "Can I try the model?"],
    },
  },
  {
    patterns: [/pric/i, /cost/i, /fee/i, /how much/i, /payment/i, /charge/i],
    response: {
      text: "FCIE is structured as a revenue-share partnership — no large upfront build cost.\n\nYou pay a percentage of the incremental revenue FCIE generates for your platform. If conversion doesn't improve, you pay nothing.\n\nThe pilot phase (Phase 1) runs for 6 weeks on one funnel segment to establish baseline and measure lift before any commercial commitment.\n\nExact revenue-share percentages are discussed during the strategy session.",
      suggestions: ["Book a strategy session", "What does the pilot include?", "How long until we see ROI?"],
    },
  },
  {
    patterns: [/deploy/i, /setup/i, /integration/i, /implement/i, /how long/i, /time to/i, /fast/i, /quick/i, /weeks/i],
    response: {
      text: "Three phases:\n\n→ Phase 1 (6 weeks): One funnel segment. Baseline risk model live. Counselor queue operational.\n\n→ Phase 2 (3 months): Full funnel coverage. Automated intervention sequences. Lender routing.\n\n→ Phase 3 (6 months): LLM reasoning layer. Real-time lender API connections. Full ROI reporting.\n\nPhase 1 requires minimal engineering from your side — mostly event stream access and a webhook endpoint.",
      suggestions: ["What data do you need from us?", "What's the ROI?", "Book a strategy session"],
    },
  },
  {
    patterns: [/lender/i, /bank/i, /hdfc/i, /sbi/i, /prodigy/i, /icici/i, /mpower/i],
    response: {
      text: "FCIE's lender-fit scoring currently models compatibility against:\n\nHDFC Credila · SBI Education · ICICI Bank · Prodigy Finance · Bank of Baroda · MPOWER Financing · Axis Bank\n\nFor each student, the engine scores profile compatibility against each lender's income, collateral, and destination requirements — then surfaces the best match before the application is submitted.\n\nNew lenders can be added within 2–3 weeks of integration.",
      suggestions: ["What's the conversion lift?", "How does routing work?", "Can I see a demo?"],
    },
  },
  {
    patterns: [/counsel/i, /team/i, /staff/i, /ops/i, /operations/i, /human/i],
    response: {
      text: "FCIE doesn't replace your counselors — it makes each one dramatically more effective.\n\nInstead of managing a flat, unsorted list of students, each counselor gets a priority queue sorted by dropout risk. They see:\n\n• Fundability score (0–100)\n• Top risk signals (SHAP-style reason codes)\n• Recommended action + expected lift\n• Days since last activity\n\nCounselors spend time on students who need them most, not whoever happens to reply first.",
      suggestions: ["What's the ROI?", "How long to deploy?", "Book a strategy session"],
    },
  },
  {
    patterns: [/document/i, /doc/i, /upload/i, /ielts/i, /toefl/i, /income proof/i, /collateral/i],
    response: {
      text: "Document Intelligence is one of FCIE's core modules.\n\nEvery uploaded file is scanned by an OCR + LLM extraction pipeline that:\n\n• Validates the document against the student's profile\n• Checks against the selected lender's minimum requirements\n• Flags income mismatches, missing IELTS, blank collateral sections\n• Sends targeted 'document missing' alerts automatically\n\nIn the prototype data, 38% of applications had at least one missing document that would have blocked lender review.",
      suggestions: ["How does the risk model work?", "What's the ROI?", "Can I try the model?"],
    },
  },
  {
    patterns: [/demo/i, /try/i, /test/i, /see it/i, /show me/i, /example/i],
    response: {
      text: "You're already seeing it live on this page.\n\nScroll down to find:\n\n→ Live Risk Analyzer — enter any student profile and get a real fundability score, reason codes, and recommended actions\n\n→ Interactive Funnel — hover each stage to see dropout root causes\n\n→ Live Counselor Queue — the real-time intervention dashboard\n\n→ 30-Day Timeline — watch what happens to one student with vs without FCIE\n\nAll of these run the actual model logic from the prototype notebook.",
      suggestions: ["What's the ROI?", "Book a strategy session", "How does pricing work?"],
    },
  },
  {
    patterns: [/book|session|call|meeting|talk|contact|pilot|partner/i],
    response: {
      text: "The fastest way forward is a 45-minute strategy session.\n\nWe'll walk through your current funnel metrics, identify the highest-impact intervention points for your specific platform, and define Phase 1 scope.\n\nNo commitment required from the session.\n\nHit the 'Book a Strategy Session' button at the top or bottom of this page — or reply with your platform name and I'll make a note.",
      suggestions: ["What data do you need from us?", "How long until ROI?", "Tell me about the pilot"],
    },
  },
  {
    patterns: [/data/i, /privacy/i, /gdpr/i, /student data/i, /secure/i, /pii/i],
    response: {
      text: "FCIE operates on your existing student data — it doesn't require moving data to external servers.\n\nThe system reads anonymised event streams and profile features. No student PII needs to leave your infrastructure.\n\nAll model training happens on your cohort data, so the risk scores improve over time as your platform grows.\n\nData handling specifics are agreed during the partnership scoping session.",
      suggestions: ["How does it integrate?", "Book a strategy session", "What's the ROI?"],
    },
  },
  {
    patterns: [/accurate/i, /precision/i, /auc/i, /accuracy/i, /how good/i, /how well/i, /performance/i],
    response: {
      text: "The prototype model achieves:\n\n• AUC 0.80–0.87 on predicting funded outcomes\n• Trained on 3,000 student records, 35 features\n• SMOTE applied for class imbalance\n• XGBoost (n_estimators=300)\n• Features include: RFM signals, time-gap features, document completeness, lender-fit scores, counselor responsiveness\n\nAUC of 0.87 means the model correctly ranks a funded student above a non-funded one 87% of the time — substantially above random (0.50).",
      suggestions: ["What's the conversion lift?", "Can I try the model?", "How does pricing work?"],
    },
  },
  {
    patterns: [/crm/i, /salesforce/i, /hubspot/i, /different/i, /vs /i, /competitor/i, /compare/i, /unlike/i],
    response: {
      text: "FCIE is not a CRM. CRMs record what happened. FCIE predicts what's about to happen and acts.\n\nThe difference:\n\n• CRM: Student went inactive. You find out when you check.\n• FCIE: Student is about to go inactive. Counselor is notified before it happens.\n\n• CRM: Lender rejection. Manual rerouting.\n• FCIE: Lender mismatch flagged before submission. Rerouting happens automatically.\n\nFCIE sits on top of your existing CRM — it adds the intelligence layer your CRM doesn't have.",
      suggestions: ["What's the ROI?", "How does it integrate?", "Book a strategy session"],
    },
  },
  {
    patterns: [/hello|hi\b|hey|good morning|good afternoon/i],
    response: {
      text: "Hi! I'm the FCIE assistant — I can answer questions about how FCIE works, the ROI numbers, deployment timeline, lender integrations, and the prototype model.\n\nWhat would you like to know?",
      suggestions: ["What is FCIE?", "What's the ROI?", "How fast can we deploy?"],
    },
  },
];

const FALLBACK: BotResponse = {
  text: "That's a good question — I might not have a specific answer for that one.\n\nFor anything outside what I can answer here, the best path is a direct strategy session where we can go through your platform specifics.\n\nIs there anything else I can help with?",
  suggestions: ["What is FCIE?", "What's the ROI?", "Book a strategy session"],
};

const WELCOME: Message = {
  id: "welcome",
  role: "bot",
  text: "Hi — I'm the FCIE assistant. Ask me anything about how FCIE works, the ROI model, deployment timeline, or the prototype results.",
  suggestions: ["What is FCIE?", "What's the ROI?", "How fast can we deploy?", "Can I try the model?"],
};

function getBotResponse(input: string): BotResponse {
  for (const entry of KB) {
    if (entry.patterns.some((p) => p.test(input))) {
      return entry.response;
    }
  }
  return FALLBACK;
}

let idCounter = 0;
function uid() {
  return `msg-${++idCounter}-${Date.now()}`;
}

export default function ChatBot() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([WELCOME]);
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const [unread, setUnread] = useState(1);
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) {
      setUnread(0);
      setTimeout(() => inputRef.current?.focus(), 300);
    }
  }, [open]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, typing]);

  function sendMessage(text: string) {
    if (!text.trim()) return;
    const userMsg: Message = { id: uid(), role: "user", text: text.trim() };
    setMessages((m) => [...m, userMsg]);
    setInput("");
    setTyping(true);

    const delay = 600 + Math.random() * 600;
    setTimeout(() => {
      const response = getBotResponse(text);
      const botMsg: Message = { id: uid(), role: "bot", ...response };
      setMessages((m) => [...m, botMsg]);
      setTyping(false);
    }, delay);
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    sendMessage(input);
  }

  return (
    <>
      {/* Floating button */}
      <motion.button
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 1.5, duration: 0.4, ease }}
        onClick={() => setOpen(true)}
        className={`fixed bottom-6 right-6 z-50 w-14 h-14 bg-black text-white rounded-full shadow-2xl flex items-center justify-center hover:bg-black/80 transition-colors ${open ? "hidden" : "flex"}`}
        aria-label="Open FCIE assistant"
      >
        <MessageCircle className="w-5 h-5" />
        {unread > 0 && (
          <motion.span
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="absolute -top-1 -right-1 w-4 h-4 bg-blue-500 rounded-full text-[9px] font-bold flex items-center justify-center text-white"
          >
            {unread}
          </motion.span>
        )}
      </motion.button>

      {/* Chat window */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 24, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 24, scale: 0.95 }}
            transition={{ duration: 0.3, ease }}
            className="fixed bottom-6 right-6 z-50 w-[360px] max-w-[calc(100vw-2rem)] bg-white shadow-2xl flex flex-col"
            style={{ height: "520px" }}
          >
            {/* Header */}
            <div className="bg-black text-white px-5 py-4 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center">
                  <span className="text-[10px] font-bold font-mono">FC</span>
                </div>
                <div>
                  <p className="text-sm font-bold leading-none">FCIE Assistant</p>
                  <p className="text-[10px] text-white/40 mt-0.5">Fundability Intelligence Engine</p>
                </div>
              </div>
              <button
                onClick={() => setOpen(false)}
                className="text-white/40 hover:text-white transition-colors"
                aria-label="Close chat"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4 scroll-smooth">
              {messages.map((msg) => (
                <motion.div
                  key={msg.id}
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.25 }}
                  className={`flex flex-col gap-2 ${msg.role === "user" ? "items-end" : "items-start"}`}
                >
                  <div
                    className={`max-w-[85%] px-4 py-3 text-sm leading-relaxed whitespace-pre-line ${
                      msg.role === "user"
                        ? "bg-black text-white"
                        : "bg-[#F5F5F7] text-black"
                    }`}
                  >
                    {msg.text}
                  </div>

                  {/* Suggestions */}
                  {msg.role === "bot" && msg.suggestions && (
                    <div className="flex flex-wrap gap-1.5 max-w-[85%]">
                      {msg.suggestions.map((s) => (
                        <button
                          key={s}
                          onClick={() => sendMessage(s)}
                          className="text-[11px] font-mono border border-black/12 px-2.5 py-1.5 text-black hover:bg-black hover:text-white transition-colors text-left"
                        >
                          {s}
                        </button>
                      ))}
                    </div>
                  )}
                </motion.div>
              ))}

              {/* Typing indicator */}
              <AnimatePresence>
                {typing && (
                  <motion.div
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    className="flex items-center gap-1.5 px-4 py-3 bg-[#F5F5F7] w-fit"
                  >
                    {[0, 0.15, 0.3].map((delay, i) => (
                      <span
                        key={i}
                        className="w-1.5 h-1.5 rounded-full bg-black/30 animate-bounce"
                        style={{ animationDelay: `${delay}s`, animationDuration: "0.9s" }}
                      />
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>

              <div ref={bottomRef} />
            </div>

            {/* Input */}
            <form
              onSubmit={handleSubmit}
              className="shrink-0 border-t border-black/8 flex items-center gap-2 px-4 py-3"
            >
              <input
                ref={inputRef}
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask anything about FCIE…"
                className="flex-1 text-sm text-black placeholder:text-[#6E6E73] bg-transparent focus:outline-none font-light"
              />
              <button
                type="submit"
                disabled={!input.trim() || typing}
                className="w-8 h-8 bg-black text-white flex items-center justify-center disabled:opacity-20 hover:bg-black/70 transition-colors shrink-0"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
