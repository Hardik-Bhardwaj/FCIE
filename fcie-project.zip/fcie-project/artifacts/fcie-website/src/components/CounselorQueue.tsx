import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Phone, MessageSquare, RefreshCw, ArrowRightLeft, FileWarning } from "lucide-react";

const ease = [0.16, 1, 0.3, 1] as const;

interface Student {
  id: string;
  name: string;
  destination: string;
  lender: string;
  loan: string;
  stage: string;
  score: number;
  daysInactive: number;
  topRisk: string;
  action: string;
  actionIcon: "phone" | "whatsapp" | "lender" | "docs" | "escalate";
  auto: boolean;
}

const SEED_STUDENTS: Student[] = [
  { id: "GR10041", name: "Rohan M.", destination: "US", lender: "HDFC Credila", loan: "₹48L", stage: "docs_submitted", score: 24, daysInactive: 12, topRisk: "Income mismatch + IELTS missing", action: "Priority counselor call", actionIcon: "phone", auto: false },
  { id: "GR10089", name: "Priya S.", destination: "Canada", lender: "ICICI Bank", loan: "₹52L", stage: "loan_started", score: 31, daysInactive: 9, topRisk: "Lender mismatch — ICICI gaps for CA", action: "Reroute to Prodigy Finance", actionIcon: "lender", auto: false },
  { id: "GR10112", name: "Arjun K.", destination: "UK", lender: "SBI Education", loan: "₹35L", stage: "shortlisted", score: 38, daysInactive: 6, topRisk: "Doc completeness 41%", action: "Send document checklist", actionIcon: "docs", auto: true },
  { id: "GR10204", name: "Sneha R.", destination: "US", lender: "Prodigy Finance", loan: "₹44L", stage: "docs_submitted", score: 44, daysInactive: 5, topRisk: "Journey stall detected", action: "WhatsApp re-engagement", actionIcon: "whatsapp", auto: true },
  { id: "GR10167", name: "Vikram P.", destination: "Germany", lender: "Bank of Baroda", loan: "₹28L", stage: "profile_complete", score: 29, daysInactive: 14, topRisk: "Critical inactivity — 14 days", action: "Escalate to senior ops", actionIcon: "escalate", auto: false },
  { id: "GR10291", name: "Ananya T.", destination: "US", lender: "HDFC Credila", loan: "₹40L", stage: "loan_started", score: 51, daysInactive: 3, topRisk: "Financial stress — 7.1x LTI ratio", action: "Financial counseling session", actionIcon: "phone", auto: false },
  { id: "GR10318", name: "Karan B.", destination: "Canada", lender: "SBI Education", loan: "₹55L", stage: "shortlisted", score: 22, daysInactive: 11, topRisk: "Collateral missing + lender mismatch", action: "Priority counselor call", actionIcon: "phone", auto: false },
  { id: "GR10445", name: "Divya N.", destination: "Australia", lender: "Axis Bank", loan: "₹32L", stage: "docs_submitted", score: 57, daysInactive: 2, topRisk: "IELTS score missing", action: "WhatsApp re-engagement", actionIcon: "whatsapp", auto: true },
];

function ActionIcon({ type }: { type: Student["actionIcon"] }) {
  const cls = "w-3.5 h-3.5";
  if (type === "phone") return <Phone className={cls} />;
  if (type === "whatsapp") return <MessageSquare className={cls} />;
  if (type === "lender") return <ArrowRightLeft className={cls} />;
  if (type === "docs") return <FileWarning className={cls} />;
  return <RefreshCw className={cls} />;
}

function ScoreBadge({ score }: { score: number }) {
  const color =
    score < 35 ? "text-red-600 bg-red-50 border-red-200"
    : score < 60 ? "text-amber-600 bg-amber-50 border-amber-200"
    : "text-emerald-600 bg-emerald-50 border-emerald-200";
  return (
    <span className={`inline-flex items-center justify-center w-10 h-10 text-sm font-black font-mono border rounded-sm shrink-0 ${color}`}>
      {score}
    </span>
  );
}

export default function CounselorQueue() {
  const [students, setStudents] = useState<Student[]>(SEED_STUDENTS);
  const [tick, setTick] = useState(0);
  const [intervened, setIntervened] = useState<Set<string>>(new Set());
  const [justActed, setJustActed] = useState<string | null>(null);

  // Simulate real-time: every 4 seconds, increment one student's daysInactive
  // and occasionally "resolve" one by improving their score
  useEffect(() => {
    const interval = setInterval(() => {
      setTick((t) => t + 1);
      setStudents((prev) => {
        const updated = [...prev];
        // Pick a random student to tick up their inactivity
        const idx = Math.floor(Math.random() * updated.length);
        if (!intervened.has(updated[idx].id)) {
          updated[idx] = { ...updated[idx], daysInactive: updated[idx].daysInactive + 1 };
        }
        // Occasionally worsen score slightly for drama
        if (Math.random() < 0.25 && updated[idx].score > 10 && !intervened.has(updated[idx].id)) {
          updated[idx] = { ...updated[idx], score: Math.max(8, updated[idx].score - 2) };
        }
        return updated;
      });
    }, 3500);
    return () => clearInterval(interval);
  }, [intervened]);

  function handleIntervene(id: string) {
    setJustActed(id);
    setIntervened((prev) => new Set([...prev, id]));
    setStudents((prev) =>
      prev.map((s) =>
        s.id === id
          ? { ...s, score: Math.min(72, s.score + Math.floor(Math.random() * 18) + 12), daysInactive: 0 }
          : s
      )
    );
    setTimeout(() => setJustActed(null), 2000);
  }

  const sorted = [...students].sort((a, b) => a.score - b.score);

  return (
    <section className="py-32 md:py-48 px-6 bg-white">
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, ease }}
          className="mb-10"
        >
          <p className="text-sm font-mono text-[#6E6E73] uppercase tracking-widest mb-4">
            Live Counselor Queue — Updates every 3.5s
          </p>
          <h2 className="text-4xl md:text-5xl font-black tracking-tight text-black mb-4">
            Your team's view. Right now.
          </h2>
          <p className="text-lg text-[#6E6E73] font-light max-w-xl">
            This is what the FCIE counselor interface looks like — ranked by urgency, updated in real-time, with one-click interventions. Hit "Act" to simulate resolving a case.
          </p>
        </motion.div>

        {/* KPI strip */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, ease, delay: 0.1 }}
          className="grid grid-cols-4 gap-px bg-black/8 mb-6"
        >
          {[
            { label: "At Risk Today", value: sorted.filter((s) => s.score < 60).length.toString() },
            { label: "Auto Actions Queued", value: sorted.filter((s) => s.auto).length.toString() },
            { label: "Intervened", value: intervened.size.toString() },
            { label: "Avg Score", value: Math.round(sorted.reduce((a, s) => a + s.score, 0) / sorted.length).toString() },
          ].map((kpi, i) => (
            <div key={i} className="bg-white px-5 py-4">
              <div className="text-2xl font-black font-mono text-black tabular-nums">{kpi.value}</div>
              <div className="text-xs text-[#6E6E73] font-mono mt-0.5">{kpi.label}</div>
            </div>
          ))}
        </motion.div>

        {/* Queue */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="border border-black/8 bg-white overflow-hidden"
        >
          {/* Header */}
          <div className="grid grid-cols-[auto_1fr_auto_auto] md:grid-cols-[auto_1fr_auto_auto_auto] gap-4 px-5 py-3 bg-[#F5F5F7] border-b border-black/8">
            <span className="text-[10px] font-mono text-[#6E6E73] uppercase tracking-widest w-10">Score</span>
            <span className="text-[10px] font-mono text-[#6E6E73] uppercase tracking-widest">Student / Risk</span>
            <span className="text-[10px] font-mono text-[#6E6E73] uppercase tracking-widest hidden md:block">Stage</span>
            <span className="text-[10px] font-mono text-[#6E6E73] uppercase tracking-widest">Action</span>
            <span className="text-[10px] font-mono text-[#6E6E73] uppercase tracking-widest w-14"></span>
          </div>

          <AnimatePresence>
            {sorted.map((s, i) => {
              const isResolved = intervened.has(s.id);
              const isActing = justActed === s.id;
              return (
                <motion.div
                  key={s.id}
                  layout
                  initial={{ opacity: 0, y: -8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, ease, delay: i * 0.04 }}
                  className={`grid grid-cols-[auto_1fr_auto_auto] md:grid-cols-[auto_1fr_auto_auto_auto] gap-4 px-5 py-4 border-b border-black/5 last:border-none items-center transition-colors ${
                    isResolved ? "bg-emerald-50/50" : s.score < 35 ? "bg-red-50/30" : "bg-white hover:bg-[#FAFAFA]"
                  }`}
                >
                  <ScoreBadge score={s.score} />

                  <div className="min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="text-sm font-bold text-black">{s.name}</span>
                      <span className="text-xs font-mono text-[#6E6E73]">{s.id}</span>
                      <span className="text-xs text-[#6E6E73]">· {s.destination} · {s.loan}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      {!isResolved && (
                        <span className={`text-[10px] font-mono ${s.score < 35 ? "text-red-500" : "text-amber-600"}`}>
                          {s.daysInactive}d inactive
                        </span>
                      )}
                      {isResolved && <span className="text-[10px] font-mono text-emerald-600">Intervened</span>}
                      <span className="text-[10px] text-[#6E6E73] truncate">{s.topRisk}</span>
                    </div>
                  </div>

                  <span className="text-[10px] font-mono text-[#6E6E73] hidden md:block capitalize whitespace-nowrap">
                    {s.stage.replace("_", " ")}
                  </span>

                  <div className="flex items-center gap-1.5">
                    <ActionIcon type={s.actionIcon} />
                    <span className={`text-[10px] font-mono hidden md:block ${s.auto ? "text-emerald-600" : "text-[#6E6E73]"}`}>
                      {s.auto ? "AUTO" : "MANUAL"}
                    </span>
                  </div>

                  <div className="w-14 flex justify-end">
                    {!isResolved ? (
                      <button
                        onClick={() => handleIntervene(s.id)}
                        className="text-[10px] font-mono font-bold bg-black text-white px-2.5 py-1.5 hover:bg-black/70 transition-colors whitespace-nowrap"
                        data-testid={`button-intervene-${s.id}`}
                      >
                        Act →
                      </button>
                    ) : (
                      <span className="text-[10px] font-mono text-emerald-600 font-bold">Done</span>
                    )}
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </motion.div>

        <p className="mt-4 text-xs font-mono text-[#6E6E73]">
          Queue ranked by fundability score (ascending). Student inactivity counters update every 3.5 seconds to simulate the live system. "Act" resolves a case and recalculates.
        </p>
      </div>
    </section>
  );
}
