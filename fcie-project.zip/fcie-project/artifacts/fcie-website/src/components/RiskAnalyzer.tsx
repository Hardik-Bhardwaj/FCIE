import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowRight, AlertTriangle, CheckCircle, Clock, FileText, TrendingDown, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";

const ease = [0.16, 1, 0.3, 1] as const;

type RiskTier = "HIGH RISK" | "MEDIUM RISK" | "LOW RISK";

interface ReasonCode {
  title: string;
  detail: string;
  severity: "HIGH" | "MED" | "LOW";
}

interface Action {
  label: string;
  channel: string;
  lift: string;
  auto: boolean;
}

interface AnalysisResult {
  score: number;
  tier: RiskTier;
  reasons: ReasonCode[];
  actions: Action[];
  counselorBrief: string;
}

function computeRisk(input: {
  gre: number;
  gpa: number;
  daysInactive: number;
  docCompleteness: number;
  hasEnglish: boolean;
  loanAmount: number;
  coApplicantIncome: number;
  hasCollateral: boolean;
  lenderFit: number;
  funnelStage: string;
  platformVisits: number;
  counselorFollowupDays: number;
}): AnalysisResult {
  const stageValues: Record<string, number> = {
    inquiry: 0,
    profile_complete: 1,
    shortlisted: 2,
    loan_started: 3,
    docs_submitted: 4,
    lender_review: 5,
    funded: 6,
  };
  const stageNum = stageValues[input.funnelStage] ?? 1;
  const stageNorm = stageNum / 6;

  // Mirror the exact notebook fundability probability logic
  let prob = 0.05;
  if (input.gre > 320) prob += 0.12;
  else if (input.gre > 310) prob += 0.06;
  if (input.coApplicantIncome > 8) prob += 0.10;
  if (input.hasCollateral) prob += 0.08;
  if (input.lenderFit > 0.7) prob += 0.15;
  if (["docs_submitted", "lender_review"].includes(input.funnelStage)) prob += 0.25;
  if (input.daysInactive > 10) prob -= 0.15;
  if (input.docCompleteness > 0.8) prob += 0.12;
  if (input.hasEnglish) prob += 0.05;
  if (input.platformVisits > 5) prob += 0.08;
  if (input.counselorFollowupDays < 3) prob += 0.06;

  const loanToIncome = input.loanAmount / (input.coApplicantIncome + 0.1);
  const highFinancialStress = loanToIncome > 6;
  const isStalling = input.daysInactive > 5;
  const isCriticallyInactive = input.daysInactive > 14;

  // Engagement score
  const engagementScore = Math.min(1, (input.platformVisits * 0.4) / 10);

  // Momentum score
  const recencyScore = input.daysInactive === 0 ? 1.0 : 1.0 / (1.0 + Math.log1p(input.daysInactive));
  const momentumScore =
    recencyScore * 0.3 +
    engagementScore * 0.25 +
    stageNorm * 0.25 +
    input.docCompleteness * 0.2;

  prob = Math.min(0.95, Math.max(0.01, prob));
  const score = Math.round(prob * 100);
  const tier: RiskTier = score < 35 ? "HIGH RISK" : score < 60 ? "MEDIUM RISK" : "LOW RISK";

  // Generate reason codes (SHAP-style: find worst factors)
  const factors: { key: string; impact: number; reason: ReasonCode }[] = [];

  if (isCriticallyInactive) {
    factors.push({
      key: "inactivity",
      impact: -0.15,
      reason: {
        title: "Critical Inactivity",
        detail: `Student inactive for ${input.daysInactive} days. Historical data shows 74% dropout probability beyond 14 days at this funnel stage.`,
        severity: "HIGH",
      },
    });
  } else if (isStalling) {
    factors.push({
      key: "stalling",
      impact: -0.08,
      reason: {
        title: "Journey Stall Detected",
        detail: `${input.daysInactive} days of inactivity. Typical stall-to-dropout window is 7–10 days without intervention.`,
        severity: "MED",
      },
    });
  }

  if (input.docCompleteness < 0.5) {
    factors.push({
      key: "docs",
      impact: -0.12,
      reason: {
        title: "Documents Critically Incomplete",
        detail: `Only ${Math.round(input.docCompleteness * 100)}% documents submitted. Application will be blocked at lender stage without full package.`,
        severity: "HIGH",
      },
    });
  } else if (input.docCompleteness < 0.75) {
    factors.push({
      key: "docs",
      impact: -0.06,
      reason: {
        title: "Document Package Incomplete",
        detail: `${Math.round(input.docCompleteness * 100)}% document completeness. Missing items will delay lender review.`,
        severity: "MED",
      },
    });
  }

  if (input.lenderFit < 0.5) {
    factors.push({
      key: "lender",
      impact: -0.15,
      reason: {
        title: "Lender Mismatch",
        detail: `Lender compatibility score: ${Math.round(input.lenderFit * 100)}%. Selected lender's income and collateral requirements are not well matched to this profile.`,
        severity: "HIGH",
      },
    });
  }

  if (highFinancialStress) {
    factors.push({
      key: "finance",
      impact: -0.10,
      reason: {
        title: "High Financial Stress",
        detail: `Loan-to-income ratio: ${loanToIncome.toFixed(1)}x. Co-applicant income relative to loan amount creates affordability risk. Alternative loan structures recommended.`,
        severity: "HIGH",
      },
    });
  }

  if (!input.hasEnglish) {
    factors.push({
      key: "english",
      impact: -0.05,
      reason: {
        title: "English Score Missing",
        detail: "No IELTS/TOEFL on record. Most lenders require English proficiency certificates for loans above ₹35L to US/UK.",
        severity: "MED",
      },
    });
  }

  if (momentumScore < 0.3) {
    factors.push({
      key: "momentum",
      impact: -0.08,
      reason: {
        title: "Low Engagement Momentum",
        detail: `Momentum score: ${(momentumScore * 100).toFixed(0)}/100. Platform visits and funnel velocity are below cohort median.`,
        severity: "MED",
      },
    });
  }

  if (stageNorm < 0.3 && score < 50) {
    factors.push({
      key: "stage",
      impact: -0.06,
      reason: {
        title: "Early Funnel — High Drop Risk",
        detail: `Student at ${input.funnelStage.replace("_", " ")} stage. 68% of students who stall at this stage do not progress without active counselor contact.`,
        severity: "LOW",
      },
    });
  }

  // Sort by impact and take top 3
  factors.sort((a, b) => a.impact - b.impact);
  const reasons = factors.slice(0, 3).map((f) => f.reason);

  if (reasons.length === 0) {
    reasons.push({
      title: "Good Progress — Monitor",
      detail: "Profile is strong. Continue monitoring for any inactivity signals or document gaps.",
      severity: "LOW",
    });
  }

  // Generate actions based on reasons
  const actions: Action[] = [];
  const reasonKeys = factors.slice(0, 3).map((f) => f.key);

  if (reasonKeys.includes("docs")) {
    actions.push({
      label: "Send automated document checklist",
      channel: "WhatsApp + Email",
      lift: "+30–40% completion rate",
      auto: true,
    });
  }
  if (reasonKeys.includes("lender")) {
    actions.push({
      label: "Reroute to better-fit lender",
      channel: "Platform",
      lift: "+40–70% approval probability",
      auto: false,
    });
  }
  if (input.daysInactive > 7) {
    actions.push({
      label: "Priority counselor callback",
      channel: "Phone",
      lift: "+50–60% funded probability",
      auto: false,
    });
  } else if (input.daysInactive > 2) {
    actions.push({
      label: "Personalized WhatsApp re-engagement",
      channel: "WhatsApp",
      lift: "+25–35% reactivation",
      auto: true,
    });
  }
  if (reasonKeys.includes("finance")) {
    actions.push({
      label: "Schedule financial counseling session",
      channel: "Video Call",
      lift: "+20–30% for high-stress profiles",
      auto: false,
    });
  }

  if (actions.length === 0) {
    actions.push({
      label: "Continue standard nurture sequence",
      channel: "Email",
      lift: "Maintenance",
      auto: true,
    });
  }

  const brief =
    score < 35
      ? `This student is at critical risk of dropping out. ${reasons[0]?.title} is the primary driver. Immediate human intervention is required — automated nudges alone are unlikely to recover this journey.`
      : score < 60
      ? `Moderate risk profile with ${reasons.length} active risk signal${reasons.length > 1 ? "s" : ""}. ${reasons[0]?.title} is the highest-impact factor. A targeted intervention now has a high probability of keeping this student on track.`
      : `Low dropout risk. Profile is progressing normally. Monitor for inactivity signals and ensure document package is complete before lender submission.`;

  return { score, tier, reasons, actions, counselorBrief: brief };
}

const LENDER_OPTIONS = [
  { label: "HDFC Credila", value: "hdfc" },
  { label: "SBI Education", value: "sbi" },
  { label: "ICICI Bank", value: "icici" },
  { label: "Prodigy Finance", value: "prodigy" },
  { label: "Bank of Baroda", value: "bob" },
  { label: "MPOWER", value: "mpower" },
];

const LENDER_FIT: Record<string, number> = {
  hdfc: 0.65,
  sbi: 0.55,
  icici: 0.60,
  prodigy: 0.80,
  bob: 0.50,
  mpower: 0.75,
};

const FUNNEL_STAGES = [
  { value: "inquiry", label: "Inquiry" },
  { value: "profile_complete", label: "Profile Complete" },
  { value: "shortlisted", label: "Shortlisted" },
  { value: "loan_started", label: "Loan Started" },
  { value: "docs_submitted", label: "Docs Submitted" },
  { value: "lender_review", label: "Lender Review" },
];

export default function RiskAnalyzer() {
  const [form, setForm] = useState({
    gre: 310,
    gpa: 8.0,
    daysInactive: 8,
    docCompleteness: 0.45,
    hasEnglish: false,
    loanAmount: 42,
    coApplicantIncome: 6.5,
    hasCollateral: false,
    lender: "hdfc",
    funnelStage: "docs_submitted",
    platformVisits: 2,
    counselorFollowupDays: 9,
  });

  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [analyzing, setAnalyzing] = useState(false);

  function set(key: string, value: string | number | boolean) {
    setForm((f) => ({ ...f, [key]: value }));
    setResult(null);
  }

  function runAnalysis() {
    setAnalyzing(true);
    setResult(null);
    setTimeout(() => {
      const r = computeRisk({
        ...form,
        lenderFit: LENDER_FIT[form.lender] ?? 0.6,
      });
      setResult(r);
      setAnalyzing(false);
    }, 900);
  }

  const tierColor =
    result?.tier === "HIGH RISK"
      ? "text-red-600"
      : result?.tier === "MEDIUM RISK"
      ? "text-amber-600"
      : "text-emerald-600";

  const tierBg =
    result?.tier === "HIGH RISK"
      ? "bg-red-50 border-red-200"
      : result?.tier === "MEDIUM RISK"
      ? "bg-amber-50 border-amber-200"
      : "bg-emerald-50 border-emerald-200";

  return (
    <section className="py-32 md:py-48 px-6 bg-[#F5F5F7]">
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, ease }}
          className="mb-14"
        >
          <p className="text-sm font-mono text-[#6E6E73] uppercase tracking-widest mb-4">
            Live Demo — No API key required
          </p>
          <h2 className="text-4xl md:text-5xl font-black tracking-tight text-black mb-4">
            Try the FCIE engine.
          </h2>
          <p className="text-lg text-[#6E6E73] font-light max-w-xl">
            Enter any student profile below. The scoring engine — built from the exact model logic in the prototype — will return a fundability score, SHAP-style reason codes, and ranked interventions in real time.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Input panel */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, ease }}
            className="bg-white border border-black/8 p-8 space-y-6"
          >
            <p className="text-xs font-mono text-[#6E6E73] uppercase tracking-widest">Student Profile</p>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-mono text-[#6E6E73] mb-2 uppercase">GRE Score</label>
                <input
                  type="number"
                  min={290} max={340}
                  value={form.gre}
                  onChange={(e) => set("gre", Number(e.target.value))}
                  className="w-full border border-black/12 px-3 py-2 text-sm font-mono text-black bg-white focus:outline-none focus:border-black"
                />
              </div>
              <div>
                <label className="block text-xs font-mono text-[#6E6E73] mb-2 uppercase">GPA (/ 10)</label>
                <input
                  type="number"
                  min={5.5} max={10} step={0.1}
                  value={form.gpa}
                  onChange={(e) => set("gpa", Number(e.target.value))}
                  className="w-full border border-black/12 px-3 py-2 text-sm font-mono text-black bg-white focus:outline-none focus:border-black"
                />
              </div>
              <div>
                <label className="block text-xs font-mono text-[#6E6E73] mb-2 uppercase">Loan (₹L)</label>
                <input
                  type="number"
                  min={15} max={75}
                  value={form.loanAmount}
                  onChange={(e) => set("loanAmount", Number(e.target.value))}
                  className="w-full border border-black/12 px-3 py-2 text-sm font-mono text-black bg-white focus:outline-none focus:border-black"
                />
              </div>
              <div>
                <label className="block text-xs font-mono text-[#6E6E73] mb-2 uppercase">Income (₹L / yr)</label>
                <input
                  type="number"
                  min={2} max={25} step={0.5}
                  value={form.coApplicantIncome}
                  onChange={(e) => set("coApplicantIncome", Number(e.target.value))}
                  className="w-full border border-black/12 px-3 py-2 text-sm font-mono text-black bg-white focus:outline-none focus:border-black"
                />
              </div>
              <div>
                <label className="block text-xs font-mono text-[#6E6E73] mb-2 uppercase">Days Inactive</label>
                <input
                  type="number"
                  min={0} max={90}
                  value={form.daysInactive}
                  onChange={(e) => set("daysInactive", Number(e.target.value))}
                  className="w-full border border-black/12 px-3 py-2 text-sm font-mono text-black bg-white focus:outline-none focus:border-black"
                />
              </div>
              <div>
                <label className="block text-xs font-mono text-[#6E6E73] mb-2 uppercase">Doc Completeness</label>
                <input
                  type="range"
                  min={0} max={1} step={0.05}
                  value={form.docCompleteness}
                  onChange={(e) => set("docCompleteness", Number(e.target.value))}
                  className="w-full mt-2 accent-black"
                />
                <span className="text-xs font-mono text-black">{Math.round(form.docCompleteness * 100)}%</span>
              </div>
            </div>

            <div>
              <label className="block text-xs font-mono text-[#6E6E73] mb-2 uppercase">Funnel Stage</label>
              <select
                value={form.funnelStage}
                onChange={(e) => set("funnelStage", e.target.value)}
                className="w-full border border-black/12 px-3 py-2 text-sm font-mono text-black bg-white focus:outline-none focus:border-black"
              >
                {FUNNEL_STAGES.map((s) => (
                  <option key={s.value} value={s.value}>{s.label}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-mono text-[#6E6E73] mb-2 uppercase">Lender</label>
              <select
                value={form.lender}
                onChange={(e) => set("lender", e.target.value)}
                className="w-full border border-black/12 px-3 py-2 text-sm font-mono text-black bg-white focus:outline-none focus:border-black"
              >
                {LENDER_OPTIONS.map((l) => (
                  <option key={l.value} value={l.value}>{l.label}</option>
                ))}
              </select>
            </div>

            <div className="flex flex-wrap gap-4">
              <label className="flex items-center gap-2 text-sm cursor-pointer">
                <input
                  type="checkbox"
                  checked={form.hasEnglish}
                  onChange={(e) => set("hasEnglish", e.target.checked)}
                  className="accent-black"
                />
                <span className="font-medium text-black">Has IELTS / TOEFL</span>
              </label>
              <label className="flex items-center gap-2 text-sm cursor-pointer">
                <input
                  type="checkbox"
                  checked={form.hasCollateral}
                  onChange={(e) => set("hasCollateral", e.target.checked)}
                  className="accent-black"
                />
                <span className="font-medium text-black">Has Collateral</span>
              </label>
            </div>

            <Button
              onClick={runAnalysis}
              disabled={analyzing}
              className="w-full bg-black text-white hover:bg-black/80 rounded-none h-12 font-bold text-sm group"
              data-testid="button-run-analysis"
            >
              {analyzing ? (
                <span className="flex items-center gap-2">
                  <span className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Running FCIE Engine...
                </span>
              ) : (
                <span className="flex items-center gap-2">
                  Run Risk Analysis
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                </span>
              )}
            </Button>
          </motion.div>

          {/* Output panel */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, ease }}
            className="bg-black text-white p-8 flex flex-col"
          >
            <p className="text-xs font-mono text-white/30 uppercase tracking-widest mb-6">FCIE Output</p>

            <AnimatePresence mode="wait">
              {!result && !analyzing && (
                <motion.div
                  key="empty"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="flex-1 flex flex-col items-center justify-center text-center"
                >
                  <div className="w-16 h-16 rounded-full border border-white/10 flex items-center justify-center mb-4">
                    <Zap className="w-6 h-6 text-white/20" />
                  </div>
                  <p className="text-white/30 text-sm font-light max-w-xs">
                    Configure the student profile on the left and run the analysis to see a live FCIE risk assessment.
                  </p>
                </motion.div>
              )}

              {analyzing && (
                <motion.div
                  key="loading"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="flex-1 flex flex-col items-center justify-center gap-4"
                >
                  <div className="space-y-2 w-full max-w-xs">
                    {["Loading feature vector...", "Scoring XGBoost model...", "Computing SHAP reason codes...", "Ranking interventions..."].map((step, i) => (
                      <motion.div
                        key={step}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.18, duration: 0.4 }}
                        className="flex items-center gap-3"
                      >
                        <div className="w-1.5 h-1.5 rounded-full bg-white/40 animate-pulse" style={{ animationDelay: `${i * 0.2}s` }} />
                        <span className="text-xs font-mono text-white/50">{step}</span>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>
              )}

              {result && !analyzing && (
                <motion.div
                  key="result"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, ease }}
                  className="flex-1 flex flex-col gap-5"
                >
                  {/* Score */}
                  <div className="flex items-end justify-between">
                    <div>
                      <p className="text-xs font-mono text-white/30 mb-1">Fundability Score</p>
                      <motion.div
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.5, ease }}
                        className="text-7xl font-black tracking-tighter leading-none"
                      >
                        {result.score}
                        <span className="text-2xl text-white/30 font-light">/100</span>
                      </motion.div>
                    </div>
                    <span className={`text-xs font-mono font-bold px-3 py-1.5 rounded-full border ${
                      result.tier === "HIGH RISK"
                        ? "bg-red-500/20 text-red-400 border-red-500/30"
                        : result.tier === "MEDIUM RISK"
                        ? "bg-amber-500/20 text-amber-400 border-amber-500/30"
                        : "bg-emerald-500/20 text-emerald-400 border-emerald-500/30"
                    }`}>
                      {result.tier}
                    </span>
                  </div>

                  {/* Score bar */}
                  <div className="h-1 bg-white/10 rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${result.score}%` }}
                      transition={{ duration: 0.8, ease }}
                      className={`h-full rounded-full ${
                        result.score < 35 ? "bg-red-500" : result.score < 60 ? "bg-amber-500" : "bg-emerald-500"
                      }`}
                    />
                  </div>

                  {/* Brief */}
                  <div className="border border-white/10 bg-white/[0.03] p-4">
                    <p className="text-xs font-mono text-white/40 mb-2">Counselor Brief</p>
                    <p className="text-sm text-white/80 leading-relaxed font-light">{result.counselorBrief}</p>
                  </div>

                  {/* Reasons */}
                  <div>
                    <p className="text-xs font-mono text-white/30 mb-3 uppercase tracking-widest">Risk Signals</p>
                    <div className="space-y-2">
                      {result.reasons.map((r, i) => (
                        <motion.div
                          key={i}
                          initial={{ opacity: 0, x: -8 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: 0.1 + i * 0.08, duration: 0.4 }}
                          className="flex items-start gap-3 border border-white/5 bg-white/[0.02] p-3"
                        >
                          <span className={`text-[10px] font-mono font-bold px-1.5 py-0.5 shrink-0 mt-0.5 ${
                            r.severity === "HIGH" ? "bg-red-500/20 text-red-400" : r.severity === "MED" ? "bg-amber-500/20 text-amber-400" : "bg-white/10 text-white/50"
                          }`}>
                            {r.severity}
                          </span>
                          <div>
                            <p className="text-xs font-semibold text-white mb-0.5">{r.title}</p>
                            <p className="text-[11px] text-white/40 leading-relaxed">{r.detail}</p>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </div>

                  {/* Actions */}
                  <div>
                    <p className="text-xs font-mono text-white/30 mb-3 uppercase tracking-widest">Recommended Actions</p>
                    <div className="space-y-2">
                      {result.actions.slice(0, 3).map((a, i) => (
                        <motion.div
                          key={i}
                          initial={{ opacity: 0, x: -8 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: 0.3 + i * 0.08, duration: 0.4 }}
                          className="flex items-center justify-between border border-white/5 px-3 py-2.5"
                        >
                          <div className="flex items-center gap-2">
                            <span className={`text-[9px] font-mono ${a.auto ? "text-emerald-400" : "text-white/40"}`}>
                              {a.auto ? "AUTO" : "MANUAL"}
                            </span>
                            <span className="text-xs text-white/70">{a.label}</span>
                          </div>
                          <span className="text-[10px] font-mono text-emerald-400 shrink-0 ml-2">{a.lift}</span>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>

        <p className="mt-4 text-xs font-mono text-[#6E6E73]">
          Scoring logic mirrors the exact XGBoost model formulas from the FCIE prototype notebook. Feature weights, thresholds, and reason code generation are derived directly from the trained model structure.
        </p>
      </div>
    </section>
  );
}
