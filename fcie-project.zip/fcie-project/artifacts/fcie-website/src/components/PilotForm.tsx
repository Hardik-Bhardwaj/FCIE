import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowRight, CheckCircle } from "lucide-react";

const ease = [0.16, 1, 0.3, 1] as const;

const VOLUME_OPTIONS = [
  { value: 500, label: "< 500 / month" },
  { value: 1000, label: "500–1,000 / month" },
  { value: 3000, label: "1,000–3,000 / month" },
  { value: 5000, label: "3,000–5,000 / month" },
  { value: 10000, label: "5,000+ / month" },
];

const CONVERSION_OPTIONS = [
  { value: "< 3%", label: "Below 3%" },
  { value: "3–5%", label: "3–5%" },
  { value: "5–8%", label: "5–8%" },
  { value: "8–12%", label: "8–12%" },
  { value: "> 12%", label: "Above 12%" },
  { value: "unknown", label: "We don't track this yet" },
];

interface FormState {
  name: string;
  email: string;
  platformName: string;
  monthlyStudents: number;
  currentConversion: string;
  message: string;
}

const EMPTY: FormState = {
  name: "",
  email: "",
  platformName: "",
  monthlyStudents: 3000,
  currentConversion: "3–5%",
  message: "",
};

export default function PilotForm() {
  const [form, setForm] = useState<FormState>(EMPTY);
  const [status, setStatus] = useState<"idle" | "submitting" | "success" | "error">("idle");
  const [errorMsg, setErrorMsg] = useState("");

  function set(key: keyof FormState, value: string | number) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name || !form.email || !form.platformName) return;

    setStatus("submitting");
    setErrorMsg("");

    try {
      const res = await fetch(`${import.meta.env.BASE_URL}api/pilot`.replace("//", "/"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: form.name,
          email: form.email,
          platformName: form.platformName,
          monthlyStudents: form.monthlyStudents,
          currentConversion: form.currentConversion,
          message: form.message || null,
        }),
      });

      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error((data as { error?: string }).error ?? "Submission failed");
      }

      setStatus("success");
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : "Something went wrong. Please try again.");
      setStatus("error");
    }
  }

  const inputCls =
    "w-full border border-black/12 px-4 py-3 text-sm text-black bg-white focus:outline-none focus:border-black transition-colors placeholder:text-[#AEAEB2]";
  const labelCls = "block text-xs font-mono text-[#6E6E73] mb-2 uppercase tracking-widest";

  return (
    <section id="request-pilot" className="py-32 md:py-48 px-6 bg-black text-white">
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, ease }}
          className="grid lg:grid-cols-2 gap-16"
        >
          {/* Left: pitch */}
          <div>
            <p className="text-sm font-mono text-white/30 uppercase tracking-widest mb-6">
              Phase 1 Pilot
            </p>
            <h2 className="text-4xl md:text-5xl font-black tracking-tight mb-6">
              Six weeks.
              <br />
              <span className="text-white/40 font-light">One funnel segment.</span>
              <br />
              Measurable lift.
            </h2>
            <p className="text-lg text-white/60 font-light leading-relaxed mb-10">
              The pilot starts with your highest-dropout funnel stage. We deploy the risk model, connect the counselor queue, and activate the first intervention sequence — then measure conversion lift against the baseline.
            </p>

            {/* What's included */}
            <div className="space-y-3">
              {[
                "Baseline funnel audit & risk model training",
                "Live counselor intervention queue",
                "Automated WhatsApp + email sequences",
                "Weekly lift reporting against baseline",
                "No upfront cost — revenue-share only",
              ].map((item, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -12 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.08, duration: 0.4, ease }}
                  className="flex items-start gap-3 text-sm"
                >
                  <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span className="text-white/70">{item}</span>
                </motion.div>
              ))}
            </div>

            <div className="mt-10 border border-white/10 p-5">
              <p className="text-xs font-mono text-white/30 mb-2">Expected Phase 1 outcome</p>
              <p className="text-2xl font-black">+1.5–2.5% conversion</p>
              <p className="text-sm text-white/40 mt-1">on the selected funnel segment within 6 weeks</p>
            </div>
          </div>

          {/* Right: form */}
          <div>
            <AnimatePresence mode="wait">
              {status === "success" ? (
                <motion.div
                  key="success"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5, ease }}
                  className="h-full flex flex-col items-center justify-center text-center py-16 border border-white/10 px-8"
                >
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 0.2, duration: 0.5, type: "spring" }}
                  >
                    <CheckCircle className="w-12 h-12 text-emerald-400 mb-6 mx-auto" />
                  </motion.div>
                  <h3 className="text-2xl font-black mb-3">Request received.</h3>
                  <p className="text-white/50 font-light leading-relaxed max-w-xs">
                    We'll reach out within 24 hours to schedule your strategy session and define the pilot scope.
                  </p>
                  <div className="mt-8 border border-white/10 px-6 py-4 text-left w-full max-w-xs">
                    <p className="text-xs font-mono text-white/30 mb-1">Your submission</p>
                    <p className="text-sm text-white font-medium">{form.name}</p>
                    <p className="text-xs text-white/40 mt-0.5">{form.platformName} · {VOLUME_OPTIONS.find(o => o.value === form.monthlyStudents)?.label}</p>
                  </div>
                </motion.div>
              ) : (
                <motion.form
                  key="form"
                  onSubmit={handleSubmit}
                  initial={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="space-y-5"
                >
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className={labelCls}>Your Name</label>
                      <input
                        type="text"
                        required
                        placeholder="Arjun Mehta"
                        value={form.name}
                        onChange={(e) => set("name", e.target.value)}
                        className={inputCls}
                      />
                    </div>
                    <div>
                      <label className={labelCls}>Work Email</label>
                      <input
                        type="email"
                        required
                        placeholder="arjun@platform.com"
                        value={form.email}
                        onChange={(e) => set("email", e.target.value)}
                        className={inputCls}
                      />
                    </div>
                  </div>

                  <div>
                    <label className={labelCls}>Platform Name</label>
                    <input
                      type="text"
                      required
                      placeholder="GradRight, Prodigy, EdFund..."
                      value={form.platformName}
                      onChange={(e) => set("platformName", e.target.value)}
                      className={inputCls}
                    />
                  </div>

                  <div>
                    <label className={labelCls}>Monthly Student Volume</label>
                    <select
                      value={form.monthlyStudents}
                      onChange={(e) => set("monthlyStudents", Number(e.target.value))}
                      className={inputCls + " cursor-pointer"}
                    >
                      {VOLUME_OPTIONS.map((o) => (
                        <option key={o.value} value={o.value}>{o.label}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className={labelCls}>Current Conversion Rate (inquiry → funded)</label>
                    <select
                      value={form.currentConversion}
                      onChange={(e) => set("currentConversion", e.target.value)}
                      className={inputCls + " cursor-pointer"}
                    >
                      {CONVERSION_OPTIONS.map((o) => (
                        <option key={o.value} value={o.value}>{o.label}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className={labelCls}>Anything specific you'd like to cover? <span className="normal-case text-white/20">(optional)</span></label>
                    <textarea
                      rows={3}
                      placeholder="e.g. We have a specific dropout problem at the docs submission stage..."
                      value={form.message}
                      onChange={(e) => set("message", e.target.value)}
                      className={inputCls + " resize-none"}
                    />
                  </div>

                  {status === "error" && (
                    <p className="text-sm text-red-400 font-mono">{errorMsg}</p>
                  )}

                  <button
                    type="submit"
                    disabled={status === "submitting" || !form.name || !form.email || !form.platformName}
                    className="w-full bg-white text-black py-4 font-bold text-sm hover:bg-white/90 transition-colors disabled:opacity-40 flex items-center justify-center gap-2 group"
                    data-testid="button-submit-pilot"
                  >
                    {status === "submitting" ? (
                      <>
                        <span className="w-3.5 h-3.5 border-2 border-black/20 border-t-black rounded-full animate-spin" />
                        Submitting...
                      </>
                    ) : (
                      <>
                        Request Pilot Access
                        <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                      </>
                    )}
                  </button>

                  <p className="text-xs text-white/20 text-center font-light">
                    No commitment required. We'll reach out within 24 hours.
                  </p>
                </motion.form>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
