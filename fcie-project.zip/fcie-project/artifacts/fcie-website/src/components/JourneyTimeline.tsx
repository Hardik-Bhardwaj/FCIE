import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence, useInView } from "framer-motion";

const ease = [0.16, 1, 0.3, 1] as const;

interface Event {
  day: number;
  label: string;
  detail: string;
  type: "neutral" | "bad" | "good" | "critical";
}

const WITHOUT: Event[] = [
  { day: 1, label: "Student signs up", detail: "Profile started. No follow-up.", type: "neutral" },
  { day: 3, label: "Picks lender (wrong fit)", detail: "Chooses SBI for a UK profile. No mismatch warning.", type: "bad" },
  { day: 5, label: "Uploads 3 documents", detail: "Stops uploading. Counselor unaware.", type: "neutral" },
  { day: 8, label: "3 days of silence", detail: "No nudge sent. Platform has no inactivity signal.", type: "bad" },
  { day: 11, label: "Counselor calls — no answer", detail: "Called 11 days in. Timing is random, not scored.", type: "bad" },
  { day: 14, label: "Application stalls", detail: "Missing IELTS and income docs. Platform doesn't detect.", type: "critical" },
  { day: 18, label: "Student opens competitor app", detail: "Engagement drops to zero. No recovery triggered.", type: "critical" },
  { day: 24, label: "Application marked inactive", detail: "Student silently churned. No revenue.", type: "critical" },
  { day: 30, label: "Student funded — elsewhere", detail: "Funded through a competitor. Permanent loss.", type: "critical" },
];

const WITH: Event[] = [
  { day: 1, label: "Student signs up", detail: "Journey Event Layer begins tracking from first touch.", type: "neutral" },
  { day: 2, label: "Lender mismatch flagged", detail: "FCIE detects SBI profile gap for UK. Suggests Prodigy Finance.", type: "good" },
  { day: 3, label: "Student switches lender", detail: "Compatibility score: 82%. Application continues.", type: "good" },
  { day: 5, label: "Doc stall detected at 3 uploads", detail: "FCIE raises document completeness flag: 41%.", type: "neutral" },
  { day: 6, label: "Automated checklist sent", detail: "WhatsApp message with missing items. 68% open rate.", type: "good" },
  { day: 7, label: "Student uploads 4 more documents", detail: "Completeness rises to 89%. Counselor queue updated.", type: "good" },
  { day: 9, label: "Counselor call — scored, timed", detail: "FCIE assigns counselor to this student at peak engagement window.", type: "good" },
  { day: 12, label: "IELTS gap flagged proactively", detail: "Auto-message sent with IELTS upload link.", type: "good" },
  { day: 16, label: "Full application submitted", detail: "All docs complete. Lender review begins.", type: "good" },
  { day: 22, label: "Lender approves", detail: "Journey completed. Student funded on your platform.", type: "good" },
  { day: 30, label: "Revenue recognised", detail: "+₹2.1L disbursement fee. Student retained.", type: "good" },
];

type EventType = Event["type"];

function DotColor(type: EventType, side: "without" | "with") {
  if (side === "without") {
    if (type === "critical") return "bg-red-500";
    if (type === "bad") return "bg-red-300";
    return "bg-black/20";
  }
  if (type === "good") return "bg-emerald-500";
  return "bg-black/30";
}

function LabelColor(type: EventType, side: "without" | "with") {
  if (side === "without") {
    if (type === "critical") return "text-red-600";
    if (type === "bad") return "text-red-400";
    return "text-black";
  }
  if (type === "good") return "text-emerald-700";
  return "text-black";
}

interface TimelineColumnProps {
  events: Event[];
  side: "without" | "with";
  active: boolean;
  onComplete: () => void;
}

function TimelineColumn({ events, side, active, onComplete }: TimelineColumnProps) {
  const [visible, setVisible] = useState(0);
  const calledComplete = useRef(false);

  useEffect(() => {
    if (!active) { setVisible(0); calledComplete.current = false; return; }
    let i = 0;
    const interval = setInterval(() => {
      i++;
      setVisible(i);
      if (i >= events.length) {
        clearInterval(interval);
        if (!calledComplete.current) {
          calledComplete.current = true;
          setTimeout(onComplete, 400);
        }
      }
    }, side === "without" ? 320 : 280);
    return () => clearInterval(interval);
  }, [active, events.length, onComplete, side]);

  const isBad = side === "without";
  const headerBg = isBad ? "bg-red-50 border-red-100" : "bg-emerald-50 border-emerald-100";
  const headerText = isBad ? "text-red-700" : "text-emerald-700";
  const lineColor = isBad ? "bg-red-100" : "bg-emerald-100";

  return (
    <div className="flex-1 min-w-0">
      {/* Header */}
      <div className={`border rounded-none px-5 py-4 mb-6 ${headerBg}`}>
        <p className={`text-xs font-mono font-bold uppercase tracking-widest ${headerText}`}>
          {isBad ? "Without FCIE" : "With FCIE"}
        </p>
        <p className={`text-sm mt-1 ${isBad ? "text-red-600" : "text-emerald-700"}`}>
          {isBad ? "Journey deteriorates. Platform is blind." : "Every signal caught. Every dropout prevented."}
        </p>
      </div>

      {/* Events */}
      <div className="relative">
        {/* Vertical line */}
        <div className={`absolute left-3.5 top-0 bottom-0 w-px ${lineColor}`} />

        <div className="space-y-1">
          <AnimatePresence>
            {events.slice(0, visible).map((ev, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: isBad ? -12 : 12 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.35, ease }}
                className="flex items-start gap-3 pl-0"
              >
                {/* Dot */}
                <div className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 z-10 ${
                  ev.type === "critical" ? "bg-red-100" : ev.type === "bad" ? "bg-red-50" : ev.type === "good" ? "bg-emerald-50" : "bg-white"
                } border ${
                  ev.type === "critical" ? "border-red-200" : ev.type === "bad" ? "border-red-100" : ev.type === "good" ? "border-emerald-200" : "border-black/8"
                }`}>
                  <span className={`w-2 h-2 rounded-full ${DotColor(ev.type, side)}`} />
                </div>

                <div className="flex-1 min-w-0 pb-4">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-[10px] font-mono text-[#6E6E73] shrink-0">Day {ev.day}</span>
                    <span className={`text-sm font-semibold ${LabelColor(ev.type, side)}`}>{ev.label}</span>
                  </div>
                  <p className="text-xs text-[#6E6E73] mt-0.5 leading-relaxed">{ev.detail}</p>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}

export default function JourneyTimeline() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });
  const [phase, setPhase] = useState<"idle" | "without" | "both" | "done">("idle");
  const [withoutDone, setWithoutDone] = useState(false);

  useEffect(() => {
    if (inView && phase === "idle") {
      setTimeout(() => setPhase("without"), 400);
    }
  }, [inView, phase]);

  function handleWithoutComplete() {
    setWithoutDone(true);
    setTimeout(() => setPhase("both"), 200);
  }

  function replay() {
    setPhase("idle");
    setWithoutDone(false);
    setTimeout(() => setPhase("without"), 100);
  }

  const withoutFinalEvent = WITHOUT[WITHOUT.length - 1];
  const withFinalEvent = WITH[WITH.length - 1];

  return (
    <section className="py-32 md:py-48 px-6 bg-white" ref={ref}>
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, ease }}
          className="mb-14"
        >
          <p className="text-sm font-mono text-[#6E6E73] uppercase tracking-widest mb-4">
            30-Day Journey Comparison
          </p>
          <h2 className="text-4xl md:text-5xl font-black tracking-tight text-black mb-4">
            Same student.
            <br />
            <span className="text-[#6E6E73] font-light">Two very different outcomes.</span>
          </h2>
          <p className="text-lg text-[#6E6E73] font-light max-w-xl">
            Scroll to watch both journeys play out in real time. Without FCIE, every signal goes undetected. With FCIE, every dropout is caught before it happens.
          </p>
        </motion.div>

        {/* Student profile card */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, ease, delay: 0.15 }}
          className="bg-[#F5F5F7] border border-black/8 px-6 py-5 mb-10 flex flex-wrap gap-6 items-center"
        >
          <div>
            <p className="text-[10px] font-mono text-[#6E6E73] uppercase tracking-widest mb-1">Student Profile</p>
            <p className="text-sm font-bold text-black">Rohan M. — GRE 308, GPA 7.8, ₹48L to UK</p>
          </div>
          <div className="flex flex-wrap gap-4 text-xs font-mono text-[#6E6E73]">
            <span>Lender: SBI Education (initial)</span>
            <span>Doc completeness: 41%</span>
            <span>IELTS: Missing</span>
            <span>Days inactive at stall: 8</span>
          </div>
        </motion.div>

        {/* Timeline columns */}
        <div className="flex gap-6 md:gap-10">
          <TimelineColumn
            events={WITHOUT}
            side="without"
            active={phase === "without" || phase === "both" || phase === "done"}
            onComplete={handleWithoutComplete}
          />

          {/* Divider */}
          <div className="w-px bg-black/8 shrink-0 hidden md:block" />

          <TimelineColumn
            events={WITH}
            side="with"
            active={phase === "both" || phase === "done"}
            onComplete={() => setPhase("done")}
          />
        </div>

        {/* Outcome summary */}
        <AnimatePresence>
          {phase === "done" && (
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease }}
              className="mt-10 grid md:grid-cols-2 gap-px bg-black/8"
            >
              <div className="bg-red-50 px-8 py-7">
                <p className="text-xs font-mono text-red-400 uppercase tracking-widest mb-2">Without FCIE — Day 30</p>
                <p className="text-2xl font-black text-red-600">₹0 revenue</p>
                <p className="text-sm text-red-500 mt-1">Student funded on a competitor platform. Journey permanently lost.</p>
              </div>
              <div className="bg-emerald-50 px-8 py-7">
                <p className="text-xs font-mono text-emerald-600 uppercase tracking-widest mb-2">With FCIE — Day 30</p>
                <p className="text-2xl font-black text-emerald-700">+₹2.1L disbursement fee</p>
                <p className="text-sm text-emerald-600 mt-1">Journey completed on-platform. Student retained. Revenue recognised.</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Replay */}
        <AnimatePresence>
          {phase === "done" && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="mt-6 flex items-center gap-4"
            >
              <button
                onClick={replay}
                className="text-xs font-mono text-[#6E6E73] hover:text-black transition-colors underline underline-offset-4"
              >
                Replay animation →
              </button>
              <p className="text-xs font-mono text-[#6E6E73]">
                Across 3,000 students/month, this difference compounds to <span className="text-black font-bold">+₹25Cr/year.</span>
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
}
