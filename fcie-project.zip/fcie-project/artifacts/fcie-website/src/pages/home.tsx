import { useEffect, useRef } from "react";
import { motion, useInView, animate } from "framer-motion";
import { ArrowRight, Check, Activity, BarChart3, BrainCircuit, FileText, Zap, FlaskConical } from "lucide-react";
import { Button } from "@/components/ui/button";
import RiskAnalyzer from "@/components/RiskAnalyzer";
import CounselorQueue from "@/components/CounselorQueue";
import InteractiveFunnel from "@/components/InteractiveFunnel";
import JourneyTimeline from "@/components/JourneyTimeline";
import PlatformComparison from "@/components/PlatformComparison";
import PilotForm from "@/components/PilotForm";

const ease = [0.16, 1, 0.3, 1] as const;

function Counter({
  to,
  suffix = "",
  prefix = "",
  decimals = 0,
  duration = 1.8,
}: {
  to: number;
  suffix?: string;
  prefix?: string;
  decimals?: number;
  duration?: number;
}) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });

  useEffect(() => {
    if (!inView || !ref.current) return;
    const controls = animate(0, to, {
      duration,
      ease: [0.16, 1, 0.3, 1],
      onUpdate(val) {
        if (ref.current) {
          ref.current.textContent =
            prefix + val.toFixed(decimals) + suffix;
        }
      },
    });
    return () => controls.stop();
  }, [inView, to, suffix, prefix, duration, decimals]);

  return (
    <span ref={ref}>
      {prefix}0{suffix}
    </span>
  );
}

const fadeUp = {
  hidden: { opacity: 0, y: 32 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.8, ease } },
};

const stagger = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.12 } },
};

const FUNNEL = [
  { stage: "Inquiry", current: 100, fcie: 100 },
  { stage: "Profile Complete", current: 59.6, fcie: 64 },
  { stage: "Shortlisted", current: 44.4, fcie: 50 },
  { stage: "Loan Started", current: 29.2, fcie: 34 },
  { stage: "Docs Submitted", current: 18.4, fcie: 23 },
  { stage: "Funded", current: 6.2, fcie: 9.2 },
];

const MODULES = [
  {
    icon: <Activity className="w-5 h-5" />,
    title: "Journey Event Layer",
    desc: "Ingests every micro-signal — clicks, uploads, timestamps, counselor outreach — into a continuously updated state of truth.",
    tag: "MOD 01",
  },
  {
    icon: <BarChart3 className="w-5 h-5" />,
    title: "Risk & Fundability Scoring",
    desc: "XGBoost models trained on 35 behavioral and financial features. Score updates on every action. Outputs a 0–100 fundability index.",
    tag: "MOD 02",
  },
  {
    icon: <BrainCircuit className="w-5 h-5" />,
    title: "Reason Engine",
    desc: "SHAP-powered explainability converts model outputs into precise plain-English reason codes. Not a number — a diagnosis.",
    tag: "MOD 03",
  },
  {
    icon: <Zap className="w-5 h-5" />,
    title: "Next-Best-Action",
    desc: "Rules plus LLM reasoning selects the exact intervention: WhatsApp checklist, counselor call, lender reroute, or escalation.",
    tag: "MOD 04",
  },
  {
    icon: <FileText className="w-5 h-5" />,
    title: "Document Intelligence",
    desc: "OCR plus field validation catches income mismatches, missing IELTS, lender-requirement failures — before the application reaches any lender.",
    tag: "MOD 05",
  },
  {
    icon: <FlaskConical className="w-5 h-5" />,
    title: "Experimentation Layer",
    desc: "Uplift modeling and A/B testing built in from day one. Every intervention is measured causally — not correlated, caused.",
    tag: "MOD 06",
  },
];

const ACTIONS = [
  { label: "Document checklist (WhatsApp)", lift: "+30–40% completion" },
  { label: "Priority counselor call", lift: "+50–60% funded probability" },
  { label: "Lender reroute", lift: "+40–70% approval probability" },
  { label: "Personalized re-engagement", lift: "+25–35% reactivation" },
];

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden selection:bg-black selection:text-white">

      {/* ── Navbar ── */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-md border-b border-black/[0.06]">
        <div className="max-w-5xl mx-auto px-6 h-14 flex items-center justify-between">
          <span className="text-base font-bold tracking-tight text-black">FCIE</span>
          <div className="hidden md:flex items-center gap-8 text-sm font-medium text-[#6E6E73]">
            <a href="#system" className="hover:text-black transition-colors">System</a>
            <a href="#results" className="hover:text-black transition-colors">Results</a>
            <a href="#roi" className="hover:text-black transition-colors">ROI</a>
            <a href="#partnership" className="hover:text-black transition-colors">Partnership</a>
          </div>
          <Button
            size="sm"
            className="bg-black text-white hover:bg-black/80 rounded-full px-5 text-sm font-semibold h-9"
          >
            Request Pilot
          </Button>
        </div>
      </nav>

      {/* ── Hero ── */}
      <section className="min-h-screen flex flex-col items-center justify-center text-center px-6 pt-14">
        <motion.div
          initial="hidden"
          animate="visible"
          variants={stagger}
          className="max-w-4xl mx-auto"
        >
          <motion.p
            variants={fadeUp}
            className="text-sm font-mono text-[#6E6E73] uppercase tracking-widest mb-8"
          >
            Fundability &amp; Conversion Intelligence Engine
          </motion.p>

          <motion.h1
            variants={fadeUp}
            className="text-5xl md:text-7xl lg:text-8xl font-black tracking-tight leading-[1.05] text-black mb-8"
          >
            The AI that saves<br />the funded outcome.
          </motion.h1>

          <motion.p
            variants={fadeUp}
            className="text-xl md:text-2xl text-[#6E6E73] max-w-2xl mx-auto leading-relaxed mb-12 font-light"
          >
            Every student financing platform loses 90%+ of applicants before funding.
            FCIE watches every journey in real-time, predicts who is about to leave, and tells your team exactly what to do — before it's too late.
          </motion.p>

          <motion.div
            variants={fadeUp}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <Button
              size="lg"
              className="bg-black text-white hover:bg-black/80 h-13 px-8 rounded-full text-base font-semibold group"
            >
              Book a Strategy Session
              <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="h-13 px-8 rounded-full text-base font-medium border-black/20 text-black hover:bg-black/[0.04]"
            >
              View Architecture
            </Button>
          </motion.div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.4, duration: 1 }}
          className="absolute bottom-8 flex flex-col items-center gap-2"
        >
          <div className="w-px h-10 bg-gradient-to-b from-transparent to-black/20" />
          <p className="text-xs text-[#6E6E73] font-mono uppercase tracking-widest">Scroll</p>
        </motion.div>
      </section>

      {/* ── Big Stat – Black Section ── */}
      <section className="bg-black text-white py-32 md:py-48 text-center px-6">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          variants={stagger}
          className="max-w-5xl mx-auto"
        >
          <motion.p variants={fadeUp} className="text-sm font-mono text-white/40 uppercase tracking-widest mb-10">
            The core problem
          </motion.p>
          <motion.div
            variants={fadeUp}
            className="text-7xl md:text-[10rem] lg:text-[13rem] font-black tracking-tighter leading-none tabular-nums"
          >
            <span className="text-white/30">6.2</span>
            <span className="text-white/40 text-5xl md:text-7xl mx-4 font-light">%</span>
            <span className="text-white/50 text-4xl md:text-6xl mx-6 font-thin">→</span>
            <span className="text-white">9.2</span>
            <span className="text-white/60 text-5xl md:text-7xl mx-4 font-light">%</span>
          </motion.div>
          <motion.p variants={fadeUp} className="mt-8 text-xl md:text-2xl text-white/50 font-light max-w-xl mx-auto">
            Funded conversion. Proven by the prototype.
            <br />A 48% relative uplift on the metric that pays your platform.
          </motion.p>
        </motion.div>
      </section>

      {/* ── What it is ── */}
      <section id="system" className="py-32 md:py-48 px-6 bg-white">
        <div className="max-w-5xl mx-auto">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            variants={stagger}
            className="text-center mb-24"
          >
            <motion.p variants={fadeUp} className="text-sm font-mono text-[#6E6E73] uppercase tracking-widest mb-5">
              Not a dashboard. Not a chatbot.
            </motion.p>
            <motion.h2 variants={fadeUp} className="text-4xl md:text-6xl font-black tracking-tight text-black leading-tight max-w-3xl mx-auto">
              An operating intelligence layer.
            </motion.h2>
            <motion.p variants={fadeUp} className="mt-6 text-lg text-[#6E6E73] max-w-2xl mx-auto leading-relaxed font-light">
              FCIE sits on top of your existing data. It builds a continuously updated record of every student's journey, scores their probability of completing and converting, surfaces the reason they're at risk, and recommends a specific action — before the funded outcome is lost.
            </motion.p>
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            variants={stagger}
            className="grid md:grid-cols-3 gap-px bg-black/8"
          >
            {[
              {
                label: "Predict",
                headline: "Who drops off next",
                body: "Inactivity patterns, document stalls, and counselor latency are all leading indicators. FCIE detects them 7–14 days before the student goes silent.",
              },
              {
                label: "Diagnose",
                headline: "Exactly why",
                body: "SHAP explainability turns every score into precise reason codes — missing IELTS, loan-to-income mismatch, lender incompatibility — in plain English.",
              },
              {
                label: "Act",
                headline: "The one right move",
                body: "A ranked intervention queue tells each counselor who to contact, what to say, and which action has the highest probability of saving that specific journey.",
              },
            ].map((item, i) => (
              <motion.div
                key={i}
                variants={fadeUp}
                className="bg-white p-10 md:p-12 flex flex-col"
              >
                <span className="text-xs font-mono text-[#6E6E73] uppercase tracking-widest mb-6">0{i + 1} — {item.label}</span>
                <h3 className="text-2xl md:text-3xl font-black tracking-tight text-black mb-4 leading-snug">{item.headline}</h3>
                <p className="text-[#6E6E73] leading-relaxed font-light">{item.body}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ── Prototype Results ── */}
      <section id="results" className="py-32 md:py-48 px-6 bg-[#F5F5F7]">
        <div className="max-w-5xl mx-auto">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            variants={stagger}
            className="mb-20"
          >
            <motion.p variants={fadeUp} className="text-sm font-mono text-[#6E6E73] uppercase tracking-widest mb-5">
              Prototype results
            </motion.p>
            <motion.h2 variants={fadeUp} className="text-4xl md:text-6xl font-black tracking-tight text-black leading-tight">
              Built. Tested.<br />Numbers attached.
            </motion.h2>
            <motion.p variants={fadeUp} className="mt-5 text-lg text-[#6E6E73] max-w-xl leading-relaxed font-light">
              A full working prototype was trained on 3,000 synthetic students modeled on real platform statistics. These are the results.
            </motion.p>
          </motion.div>

          {/* Stat grid */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            variants={stagger}
            className="grid grid-cols-2 md:grid-cols-4 gap-px bg-black/8 mb-px"
          >
            {[
              { n: 3000, suffix: "", label: "Students modeled", decimals: 0 },
              { n: 35, suffix: "", label: "Engineered features", decimals: 0 },
              { n: 0.87, suffix: "", label: "Model ROC-AUC", decimals: 2, prefix: "" },
              { n: 75, suffix: "%", label: "Funded precision", decimals: 0 },
            ].map((stat, i) => (
              <motion.div key={i} variants={fadeUp} className="bg-white p-8 md:p-10">
                <div className="text-4xl md:text-5xl font-black tracking-tight text-black tabular-nums mb-2">
                  <Counter to={stat.n} suffix={stat.suffix} decimals={stat.decimals} />
                </div>
                <p className="text-sm text-[#6E6E73] font-medium">{stat.label}</p>
              </motion.div>
            ))}
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            variants={stagger}
            className="grid grid-cols-2 md:grid-cols-4 gap-px bg-black/8"
          >
            {[
              { n: 80, suffix: "%", label: "At-risk recall", decimals: 0 },
              { n: 55, suffix: "", label: "Additional funded / month", decimals: 0 },
              { n: 34, suffix: "%", label: "Reactivation rate", decimals: 0 },
              { n: 2.1, suffix: " Cr", label: "Incremental revenue / month (₹)", decimals: 1, prefix: "" },
            ].map((stat, i) => (
              <motion.div key={i} variants={fadeUp} className="bg-white p-8 md:p-10">
                <div className="text-4xl md:text-5xl font-black tracking-tight text-black tabular-nums mb-2">
                  <Counter to={stat.n} suffix={stat.suffix} decimals={stat.decimals} prefix={stat.prefix ?? ""} />
                </div>
                <p className="text-sm text-[#6E6E73] font-medium">{stat.label}</p>
              </motion.div>
            ))}
          </motion.div>

          {/* Model note */}
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4, duration: 0.8 }}
            className="mt-6 text-xs text-[#6E6E73] font-mono"
          >
            Model: XGBoost (n_estimators=300, AUC 0.80–0.87). SMOTE applied for class imbalance. Features include RFM signals, time-gap features, document completeness, lender-fit scores, and counselor responsiveness. Revenue based on GradRight public data (BusinessToday, Jan 2024). Conservative 50% of industry benchmark uplift.
          </motion.p>
        </div>
      </section>

      {/* ── Funnel Visualization ── */}
      <section className="py-32 md:py-48 px-6 bg-white">
        <div className="max-w-5xl mx-auto">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            variants={stagger}
            className="mb-16"
          >
            <motion.p variants={fadeUp} className="text-sm font-mono text-[#6E6E73] uppercase tracking-widest mb-5">
              The funnel
            </motion.p>
            <motion.h2 variants={fadeUp} className="text-4xl md:text-6xl font-black tracking-tight text-black">
              Where students disappear.
              <br />
              <span className="text-[#6E6E73] font-light">And where FCIE intervenes.</span>
            </motion.h2>
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            variants={stagger}
            className="space-y-4"
          >
            {FUNNEL.map((row, i) => (
              <motion.div key={i} variants={fadeUp} className="flex items-center gap-4">
                <div className="w-28 text-xs font-mono text-[#6E6E73] text-right shrink-0 uppercase tracking-wide leading-tight">
                  {row.stage}
                </div>
                <div className="flex-1 flex flex-col gap-1.5">
                  {/* Current */}
                  <div className="flex items-center gap-3">
                    <div
                      className="h-7 bg-black/10 rounded-sm transition-all"
                      style={{ width: `${row.current}%` }}
                    />
                    <span className="text-xs font-mono text-[#6E6E73] shrink-0">{row.current}%</span>
                  </div>
                  {/* FCIE */}
                  <div className="flex items-center gap-3">
                    <motion.div
                      initial={{ width: 0 }}
                      whileInView={{ width: `${row.fcie}%` }}
                      viewport={{ once: true }}
                      transition={{ duration: 1.2, ease, delay: i * 0.08 }}
                      className="h-7 bg-black rounded-sm"
                    />
                    <span className="text-xs font-mono text-black font-bold shrink-0">{row.fcie}%</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.8 }}
            className="mt-10 flex items-center gap-6 text-xs font-mono text-[#6E6E73]"
          >
            <div className="flex items-center gap-2">
              <div className="w-5 h-3 bg-black/10 rounded-sm" />
              Current
            </div>
            <div className="flex items-center gap-2">
              <div className="w-5 h-3 bg-black rounded-sm" />
              With FCIE
            </div>
          </motion.div>
        </div>
      </section>

      <InteractiveFunnel />

      {/* ── Six Modules ── */}
      <section className="py-32 md:py-48 px-6 bg-[#F5F5F7]">
        <div className="max-w-5xl mx-auto">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            variants={stagger}
            className="mb-20"
          >
            <motion.p variants={fadeUp} className="text-sm font-mono text-[#6E6E73] uppercase tracking-widest mb-5">
              Architecture
            </motion.p>
            <motion.h2 variants={fadeUp} className="text-4xl md:text-6xl font-black tracking-tight text-black">
              Six modules.<br />One closed loop.
            </motion.h2>
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            variants={stagger}
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-px bg-black/8"
          >
            {MODULES.map((mod, i) => (
              <motion.div
                key={i}
                variants={fadeUp}
                className="bg-white p-8 flex flex-col group hover:bg-[#F5F5F7] transition-colors"
              >
                <div className="flex items-center justify-between mb-8">
                  <div className="text-black">{mod.icon}</div>
                  <span className="text-xs font-mono text-[#6E6E73]">{mod.tag}</span>
                </div>
                <h3 className="text-lg font-bold text-black mb-3 tracking-tight">{mod.title}</h3>
                <p className="text-sm text-[#6E6E73] leading-relaxed font-light">{mod.desc}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ── Reason Engine Sample ── */}
      <section className="py-32 md:py-48 px-6 bg-black text-white">
        <div className="max-w-5xl mx-auto">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            variants={stagger}
            className="mb-16"
          >
            <motion.p variants={fadeUp} className="text-sm font-mono text-white/40 uppercase tracking-widest mb-5">
              The Reason Engine
            </motion.p>
            <motion.h2 variants={fadeUp} className="text-4xl md:text-6xl font-black tracking-tight">
              A score tells you nothing.
              <br />
              <span className="text-white/40">A diagnosis tells you everything.</span>
            </motion.h2>
          </motion.div>

          {/* Sample output */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            variants={stagger}
            className="space-y-4"
          >
            <motion.div variants={fadeUp} className="border border-white/10 bg-white/[0.03] p-8">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <span className="text-xs font-mono text-white/40 uppercase tracking-widest">Student GR10041 · Fundability Score</span>
                  <div className="text-5xl font-black tracking-tight mt-1">
                    24<span className="text-2xl text-white/30 font-light">/100</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="inline-block px-3 py-1 bg-red-500/20 text-red-400 text-xs font-mono uppercase tracking-wider rounded-full">High Risk</span>
                  <div className="text-xs font-mono text-white/30 mt-2">US · HDFC Credila · ₹48L</div>
                </div>
              </div>
              <div className="space-y-3">
                {[
                  { severity: "HIGH", label: "Document Incomplete", detail: "Doc completeness: 34% — IELTS certificate and income proof missing. Application will be blocked at lender stage." },
                  { severity: "HIGH", label: "Inactivity Risk", detail: "Student inactive for 12 days. Historical data shows 74% dropout probability beyond 10 days at this stage." },
                  { severity: "MED", label: "Lender Mismatch", detail: "HDFC Credila requires ₹7L+ co-applicant income. Student profile: ₹5.1L. Consider Prodigy Finance or SBI Scholar." },
                ].map((r, i) => (
                  <div key={i} className="flex items-start gap-4 p-4 bg-white/[0.03] border border-white/5">
                    <span className={`text-xs font-mono uppercase tracking-wider px-2 py-0.5 rounded shrink-0 mt-0.5 ${r.severity === "HIGH" ? "bg-red-500/20 text-red-400" : "bg-amber-500/20 text-amber-400"}`}>
                      {r.severity}
                    </span>
                    <div>
                      <p className="text-sm font-semibold text-white mb-1">{r.label}</p>
                      <p className="text-xs text-white/50 leading-relaxed">{r.detail}</p>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-6 pt-6 border-t border-white/10">
                <p className="text-xs font-mono text-white/40 mb-3 uppercase tracking-widest">Priority action</p>
                <p className="text-sm text-white/80">Send automated document checklist via WhatsApp. Escalate to counselor callback within 24 hours. Consider rerouting to Prodigy Finance — profile compatibility 82%.</p>
              </div>
            </motion.div>

            {/* Actions */}
            <motion.div variants={fadeUp} className="grid sm:grid-cols-2 gap-4">
              {ACTIONS.map((a, i) => (
                <div key={i} className="border border-white/10 bg-white/[0.02] p-5 flex items-center justify-between group">
                  <span className="text-sm text-white/70 font-light">{a.label}</span>
                  <span className="text-xs font-mono text-emerald-400 shrink-0 ml-4">{a.lift}</span>
                </div>
              ))}
            </motion.div>
          </motion.div>
        </div>
      </section>

      <RiskAnalyzer />

      <JourneyTimeline />

      {/* ── ROI ── */}
      <section id="roi" className="py-32 md:py-48 px-6 bg-white">
        <div className="max-w-5xl mx-auto">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            variants={stagger}
            className="mb-20"
          >
            <motion.p variants={fadeUp} className="text-sm font-mono text-[#6E6E73] uppercase tracking-widest mb-5">
              Revenue impact
            </motion.p>
            <motion.h2 variants={fadeUp} className="text-4xl md:text-6xl font-black tracking-tight text-black">
              Conservative. Provable. Real.
            </motion.h2>
          </motion.div>

          {/* Big ROI number */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={stagger}
            className="text-center py-20 md:py-32 bg-black"
          >
            <motion.p variants={fadeUp} className="text-sm font-mono text-white/30 uppercase tracking-widest mb-4">
              Incremental revenue per year
            </motion.p>
            <motion.div variants={fadeUp} className="text-7xl md:text-9xl font-black tracking-tighter text-white tabular-nums">
              ₹<Counter to={25} suffix=" Cr" decimals={0} duration={2} />
            </motion.div>
            <motion.p variants={fadeUp} className="mt-4 text-base text-white/40 font-mono max-w-md mx-auto">
              Based on 1,847 monthly applicants, 6.2% → 9.2% funded conversion, ₹38L avg loan, 1% platform commission
            </motion.p>
          </motion.div>

          {/* Breakdown table */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            variants={stagger}
            className="mt-px bg-black/8"
          >
            {[
              ["Monthly applicants", "1,847"],
              ["Current funded conversion", "6.2%"],
              ["Target with FCIE", "9.2%  (+48% relative)"],
              ["Additional funded / month", "+55 students"],
              ["Avg loan size", "₹38L"],
              ["Incremental loan volume / month", "₹209 Cr"],
              ["Incremental platform revenue / month", "₹2.1 Cr"],
              ["Incremental platform revenue / year", "₹25 Cr"],
            ].map(([label, value], i) => (
              <motion.div
                key={i}
                variants={fadeUp}
                className="flex items-center justify-between px-6 py-5 bg-white border-b border-black/5 last:border-none hover:bg-[#F5F5F7] transition-colors"
              >
                <span className="text-sm text-[#6E6E73] font-light">{label}</span>
                <span className="text-sm font-mono font-bold text-black">{value}</span>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      <CounselorQueue />

      {/* ── Document Intelligence ── */}
      <section className="py-32 md:py-48 px-6 bg-[#F5F5F7]">
        <div className="max-w-5xl mx-auto">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            variants={stagger}
            className="grid md:grid-cols-2 gap-20 items-center"
          >
            <div>
              <motion.p variants={fadeUp} className="text-sm font-mono text-[#6E6E73] uppercase tracking-widest mb-5">
                Document Intelligence
              </motion.p>
              <motion.h2 variants={fadeUp} className="text-4xl md:text-5xl font-black tracking-tight text-black leading-tight mb-6">
                Catch the problem before the lender does.
              </motion.h2>
              <motion.p variants={fadeUp} className="text-lg text-[#6E6E73] leading-relaxed font-light mb-8">
                OCR plus LLM extraction reads every uploaded document and validates it against the student's profile and the lender's minimum requirements. Income mismatches, missing IELTS, blank collateral sections — all flagged instantly.
              </motion.p>
              <motion.ul variants={stagger} className="space-y-3">
                {[
                  "Income mismatch detection (>15% discrepancy flagged)",
                  "Lender minimum income cross-check",
                  "Missing IELTS / TOEFL for US loans above ₹40L",
                  "Admit letter presence validation",
                  "Overall document completeness scoring",
                ].map((item, i) => (
                  <motion.li key={i} variants={fadeUp} className="flex items-start gap-3 text-sm text-[#6E6E73]">
                    <Check className="w-4 h-4 text-black mt-0.5 shrink-0" />
                    {item}
                  </motion.li>
                ))}
              </motion.ul>
            </div>

            <motion.div variants={fadeUp} className="space-y-3">
              <div className="bg-white border border-black/8 p-5">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-mono text-[#6E6E73]">GR10001 · HDFC Credila</span>
                  <span className="text-xs font-mono text-red-600 font-bold">FLAGGED</span>
                </div>
                <p className="text-sm text-black">Income mismatch: ₹8.2L declared vs ₹5.1L in document. IELTS certificate missing. Lender minimum not met.</p>
              </div>
              <div className="bg-white border border-black/8 p-5">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-mono text-[#6E6E73]">GR10004 · SBI Scholar</span>
                  <span className="text-xs font-mono text-amber-600 font-bold">WARNING</span>
                </div>
                <p className="text-sm text-black">Section C (Collateral) blank. SBI requires collateral documentation for loans above ₹35L.</p>
              </div>
              <div className="bg-white border border-black/8 p-5">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-mono text-[#6E6E73]">GR10006 · Bank of Baroda</span>
                  <span className="text-xs font-mono text-emerald-600 font-bold">CLEAN</span>
                </div>
                <p className="text-sm text-black">All fields verified. Income, collateral, and English score confirmed. Ready for submission.</p>
              </div>
              <p className="text-xs font-mono text-[#6E6E73] pt-2">
                47 documents scanned today · 6 flagged · 11 warnings · 30 clean
              </p>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* ── Partnership ── */}
      <PlatformComparison />

      <section id="partnership" className="py-32 md:py-48 px-6 bg-black text-white text-center">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          variants={stagger}
          className="max-w-3xl mx-auto"
        >
          <motion.p variants={fadeUp} className="text-sm font-mono text-white/30 uppercase tracking-widest mb-8">
            The model
          </motion.p>
          <motion.h2 variants={fadeUp} className="text-5xl md:text-7xl font-black tracking-tight leading-tight mb-8">
            You get outcomes.
            <br />
            <span className="text-white/30">Not code.</span>
          </motion.h2>
          <motion.p variants={fadeUp} className="text-xl text-white/50 font-light leading-relaxed mb-14 max-w-2xl mx-auto">
            FCIE is a fully managed intelligence layer. A dedicated AI engineering team builds, trains, and evolves the models using your historical data. We own the system. You own the results. Zero engineering lift required from your team.
          </motion.p>

          <motion.div
            variants={stagger}
            className="grid sm:grid-cols-2 gap-px bg-white/10 text-left mb-16"
          >
            {[
              { n: "Phase 1", label: "6 weeks", detail: "One funnel segment, baseline risk model, counselor queue live." },
              { n: "Phase 2", label: "3 months", detail: "All six modules, document AI, real-time scoring, A/B testing." },
              { n: "Phase 3", label: "6 months", detail: "Lender routing optimization, LLM reasoning, full ROI reporting." },
              { n: "Ongoing", label: "Dedicated team", detail: "Model retraining, drift monitoring, new feature engineering." },
            ].map((item, i) => (
              <motion.div key={i} variants={fadeUp} className="bg-black p-8">
                <span className="text-xs font-mono text-white/30 uppercase tracking-widest">{item.n}</span>
                <div className="text-2xl font-black text-white mt-2 mb-2">{item.label}</div>
                <p className="text-sm text-white/40 font-light">{item.detail}</p>
              </motion.div>
            ))}
          </motion.div>

          <motion.div variants={fadeUp}>
            <Button
              size="lg"
              className="bg-white text-black hover:bg-white/90 h-14 px-10 rounded-full text-base font-bold group"
            >
              Request a Pilot
              <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
            </Button>
          </motion.div>
        </motion.div>
      </section>

      {/* ── Pilot Form CTA ── */}
      <PilotForm />

      {/* ── Footer ── */}
      <footer className="py-10 px-6 border-t border-black/8">
        <div className="max-w-5xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 text-xs font-mono text-[#6E6E73]">
          <span>FCIE SYSTEMS © {new Date().getFullYear()}</span>
          <div className="flex gap-6">
            <a href="#" className="hover:text-black transition-colors">Privacy</a>
            <a href="#" className="hover:text-black transition-colors">Terms</a>
            <a href="#" className="hover:text-black transition-colors">Contact</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
