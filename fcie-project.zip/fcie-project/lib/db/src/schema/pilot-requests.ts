import { pgTable, serial, text, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const pilotRequestsTable = pgTable("pilot_requests", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  platformName: text("platform_name").notNull(),
  monthlyStudents: integer("monthly_students").notNull(),
  currentConversion: text("current_conversion").notNull(),
  message: text("message"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertPilotRequestSchema = createInsertSchema(pilotRequestsTable).omit({
  id: true,
  createdAt: true,
});

export type InsertPilotRequest = z.infer<typeof insertPilotRequestSchema>;
export type PilotRequest = typeof pilotRequestsTable.$inferSelect;
